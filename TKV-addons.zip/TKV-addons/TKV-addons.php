<?php
/**
 * Plugin Name: TKV Addons
 * Plugin URI: https://tkvcreatographics.com
 * Description: Extra elements for Elementor. It was built for TKV theme.
 * Version: 1.3.0
 * Author: TKV Creatographics
 * Author URI: https://tkvcreatographics.com
 * License: GPL2+
 * Text Domain: TKV-addons
 * Domain Path: /languages
 */
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

if ( ! defined( 'TKV_ADDONS_VER' ) ) {
	define( 'TKV_ADDONS_VER', '1.0.0' );
}

if ( ! defined( 'TKV_ADDONS_DIR' ) ) {
	define( 'TKV_ADDONS_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'TKV_ADDONS_URL' ) ) {
	define( 'TKV_ADDONS_URL', plugin_dir_url( __FILE__ ) );
}

require_once TKV_ADDONS_DIR . 'plugin.php';

\TKV\Addons::instance();