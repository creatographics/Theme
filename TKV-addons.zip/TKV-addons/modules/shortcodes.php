<?php

namespace TKV\Addons\Modules;

/**
 * Class for shortcodes.
 */
class Shortcodes {
	/**
	 * Instance
	 *
	 * @var $instance
	 */
	protected static $instance = null;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		$this->init();
	}

	/**
	 * Init shortcodes
	 */
	public static function init() {
		add_shortcode( 'TKV_year', array( __CLASS__, 'year' ) );
		add_shortcode( 'TKV_more', array( __CLASS__, 'TKV_more_shortcode' ) );
		add_shortcode( 'TKV_last_revised', array( __CLASS__, 'last_revised_date' ) );
	}

	/**
	 * Display current year
	 *
	 * @return void
	 */
	public static function year() {
		return date('Y');
	}

	/**
	 * Show more
	 *
	 * @return void
	 */
	public static function TKV_more_shortcode( $args, $content ) {
		$default = array(
			'more'   => esc_html__( 'Show More', 'TKV-addons' ),
			'less'   => esc_html__( 'Show Less', 'TKV-addons' )
		);

		$atts = shortcode_atts( $default, $args );
   		$content = do_shortcode( $content );

		return sprintf(
			'<div class="TKV-more" data-settings="%s">
				<div class="TKV-more__content">%s</div>
				<button class="TKV-more__button TKV-button--subtle">%s</button>
			</div>',
			htmlspecialchars( json_encode( $default ) ),
			$content,
			$atts['more']
		);
	}

	/**
	 * Display last update date
	 *
	 * @return void
	 */
	public static function last_revised_date() {
		return get_the_date();
	}
}