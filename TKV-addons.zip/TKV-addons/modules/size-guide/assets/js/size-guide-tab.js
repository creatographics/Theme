jQuery( document ).ready( function( $ ) {
	$( '.TKV-size-guide-tabs' ).on( 'click', '.TKV-size-guide-tabs__nav li', function() {
        var $tab = $( this ),
            index = $tab.data( 'target' ),
            $panels = $tab.closest( '.TKV-size-guide-tabs' ).find( '.TKV-size-guide-tabs__panels' ),
            $panel = $panels.find( '.TKV-size-guide-tabs__panel[data-panel="' + index + '"]' );

        if ( $tab.hasClass( 'active' ) ) {
            return;
        }

        $tab.addClass( 'active' ).siblings( 'li.active' ).removeClass( 'active' );

        if ( $panel.length ) {
            $panel.addClass( 'active' ).siblings( '.TKV-size-guide-tabs__panel.active' ).removeClass( 'active' );
        }
    } );
} );