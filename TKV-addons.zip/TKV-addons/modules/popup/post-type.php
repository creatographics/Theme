<?php

namespace TKV\Addons\Modules\Popup;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Main class of plugin for admin
 */
class Post_Type  {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	const POST_TYPE     = 'TKV_popup';
	const TAXONOMY_TAB_TYPE     = 'TKV_popup_type';


	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
			// Make sure the post types are loaded for imports
		add_action( 'import_start', array( $this, 'register_post_type' ) );
		$this->register_post_type();

	}

	/**
	 * Register popup post type
     *
	 * @since 1.0.0
     *
     * @return void
	 */
	public function register_post_type() {
		if(post_type_exists(self::POST_TYPE)) {
			return;
		}

		register_post_type( self::POST_TYPE, array(
			'description'         => esc_html__( 'Theme Popup', 'TKV-addons' ),
			'labels'              => array(
				'name'                  => esc_html__( 'Theme Popup', 'TKV-addons' ),
				'singular_name'         => esc_html__( 'Theme Popup', 'TKV-addons' ),
				'menu_name'             => esc_html__( 'Theme Popup', 'TKV-addons' ),
				'all_items'             => esc_html__( 'Theme Popup', 'TKV-addons' ),
				'add_new'               => esc_html__( 'Add New', 'TKV-addons' ),
				'add_new_item'          => esc_html__( 'Add New Popup', 'TKV-addons' ),
				'edit_item'             => esc_html__( 'Edit Popup', 'TKV-addons' ),
				'new_item'              => esc_html__( 'New Popup', 'TKV-addons' ),
				'view_item'             => esc_html__( 'View Popup', 'TKV-addons' ),
				'search_items'          => esc_html__( 'Search popup', 'TKV-addons' ),
				'not_found'             => esc_html__( 'No popup found', 'TKV-addons' ),
				'not_found_in_trash'    => esc_html__( 'No popup found in Trash', 'TKV-addons' ),
				'filter_items_list'     => esc_html__( 'Filter popups list', 'TKV-addons' ),
				'items_list_navigation' => esc_html__( 'Popup list navigation', 'TKV-addons' ),
				'items_list'            => esc_html__( 'Popup list', 'TKV-addons' ),
			),
			'supports'            => array( 'title', 'editor', 'elementor' ),
			'public'              => true,
			'rewrite'             => false,
			'show_ui'             => true,
			'show_in_menu'        => false,
			'show_in_nav_menus'   => false,
			'exclude_from_search' => true,
			'capability_type'     => 'post',
			'hierarchical'        => false,
			'show_in_menu'        => 'themes.php',
		) );

	}


}