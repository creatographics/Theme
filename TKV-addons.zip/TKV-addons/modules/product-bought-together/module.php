<?php
/**
 * TKV Addons Modules functions and definitions.
 *
 * @package TKV
 */

namespace TKV\Addons\Modules\Product_Bought_Together;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Addons Modules
 */
class Module {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		$this->includes();
		$this->actions();
	}

	/**
	 * Includes files
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	private function includes() {
		\TKV\Addons\Auto_Loader::register( [
			'TKV\Addons\Modules\Product_Bought_Together\Frontend'        => TKV_ADDONS_DIR . 'modules/product-bought-together/frontend.php',
			'TKV\Addons\Modules\Product_Bought_Together\Settings'    	=> TKV_ADDONS_DIR . 'modules/product-bought-together/settings.php',
			'TKV\Addons\Modules\Product_Bought_Together\Product_Meta'    => TKV_ADDONS_DIR . 'modules/product-bought-together/product-meta.php',
		] );
	}


	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function actions() {
		if ( is_admin() ) {
			\TKV\Addons\Modules\Product_Bought_Together\Settings::instance();
		}

		if ( get_option( 'TKV_product_bought_together', 'yes' ) == 'yes' ) {
			\TKV\Addons\Modules\Product_Bought_Together\Frontend::instance();

			if ( is_admin() ) {
				\TKV\Addons\Modules\Product_Bought_Together\Product_Meta::instance();
			}
		}

	}

}
