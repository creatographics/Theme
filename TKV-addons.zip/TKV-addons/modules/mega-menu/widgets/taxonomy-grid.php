<?php
/**
 * Widget Image
 */

namespace TKV\Addons\Modules\Mega_Menu\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Taxonomy Grid widget class
 */
class Taxonomy_Grid extends Widget_Base {

	/**
	 * Set the widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'taxonomy-grid';
	}

	/**
	 * Set the widget label
	 *
	 * @return string
	 */
	public function get_label() {
		return esc_html__( 'Taxonomy Grid', 'TKV-addons' );
	}

	/**
	 * Default widget options
	 *
	 * @return array
	 */
	public function get_defaults() {
		return array(
			'title'  		=> '',
			'taxonomy' 		=> 'product_cat',
			'order'     	=> '',
			'orderby'   	=> '',
			'limit'  		=> '',
			'include'   	=> '',
			'exclude'   	=> '',
			'hide_empty'    => '',
			'hide_title'  	=> '',
			'all_cats'  	=> '',
		);
	}

	/**
	 * Render widget content
	 */
	public function render() {
		$data = $this->get_data();

		$args = array(
			'taxonomy' 		=> $data['taxonomy'],
			'number' 		=> $data['limit'],
		);

		$args['order'] 		= $data['order'] ? $data['order'] : 'asc';
		$args['exclude']	= $data['exclude'] ? $data['exclude'] : '';
		$args['hide_empty'] = $data['hide_empty'] ? true : false;

		if ( $data['orderby'] ) {
			$args['orderby'] = $data['orderby'];

			if ( $data['orderby'] == 'count' ) {
				$args['order'] = 'desc';
			}
		} else {
			$args['orderby'] = 'title';
		}

		if ( $data['include'] ) {
			$args['include'] = explode( ',', $data['include'] );
			$args['orderby'] = 'include';
		}

		$args = apply_filters( 'TKV_addons_menu_widget_taxonomy_grid_args', $args );

		$terms = get_terms( $args );

		if ( empty( $terms ) ) {
			return;
		}

		$classes = $data['classes'] ? ' ' . $data['classes'] : '';
		$classes .= $data['hide_title'] ? ' taxonomy-grid-hide-title' : '';

		if ( $data['title'] ) {
			echo '<div class="menu-taxonomy-grid-widget__heading">'. esc_html( $data['title'] ) .'</div>';
		}

		echo '<ul class="menu-taxonomy-grid-widget'. esc_attr( $classes ) .'">';

		foreach ( $terms as $term ) {
			$thumbnail_name = $data['taxonomy'] == 'product_brand' ? 'brand_thumbnail_id' : 'thumbnail_id';
			$thumbnail_id 	= get_term_meta( $term->term_id, $thumbnail_name, true );
			$image_url 		= wp_get_attachment_url( $thumbnail_id );
			$link_url 		= get_term_link( $term->slug, $data['taxonomy'] );

			$image = $image_url ? '<span class="menu-taxonomy-grid-widget__image"><img alt="'. esc_html( $term->name ) .'" src="'. esc_url( $image_url ) .'"/></span>' : '';
			$title = $data['hide_title'] ? '' : '<span class="menu-taxonomy-grid-widget__name">'. esc_html( $term->name ) .'</span>';

			echo sprintf(
				'<li class="menu-taxonomy-grid-widget__item">
					<a href="%s">%s%s</a>
				</li>',
				esc_url( $link_url ),
				$image,
				$title
			);
		}

		$page_id = get_option( 'TKV_product_brand_page_id' );
		$text_all = '<span>'. esc_html__( 'See All', 'TKV-addons' ) .'</span>';

		if ( $data['all_cats'] && $data['taxonomy'] == 'product_brand' ) {
			echo '<li class="menu-taxonomy-grid-widget__item menu-taxonomy-grid-widget__item--all-cats">';

			if ( $page_id && get_option( 'TKV_product_brand', 'yes' ) == 'yes' ) {
				echo '<a href="'. get_page_link( $page_id ) .'">'. $text_all .'</a>';
			} else {
				echo $text_all;
			}

			echo '</li>';
		}

		echo '</ul>';
	}

	/**
	 * Widget setting fields.
	 */
	public function add_controls() {
		$this->add_control( array(
			'type' => 'text',
			'name' => 'title',
			'label' => esc_html__( 'Navigation Label', 'TKV-addons' ),
		) );

		$this->add_control( array(
			'type' => 'select',
			'name' => 'taxonomy',
			'label' => esc_html__( 'Taxonomy', 'TKV-addons' ),
			'class' => 'TKV-menu-item-taxonomy',
			'options' => self::get_taxonomy(),
		) );

		$this->add_control( array(
			'type' => 'select',
			'name' => 'order',
			'label' => esc_html__( 'Order', 'TKV-addons' ),
			'options' => array(
				'0'  	=> esc_html__( 'Default', 'TKV-addons' ),
				'asc'  	=> esc_html__( 'Ascending', 'TKV-addons' ),
				'desc' 	=> esc_html__( 'Descending', 'TKV-addons' ),
			),
			'value' => ''
		) );

		$this->add_control( array(
			'type' => 'select',
			'name' => 'orderby',
			'label' => esc_html__( 'Order By', 'TKV-addons' ),
			'options' => array(
				'0'  			=> esc_html__( 'Default', 'TKV-addons' ),
				'id'  			=> esc_html__( 'ID', 'TKV-addons' ),
				'title' 		=> esc_html__( 'Title', 'TKV-addons' ),
				'menu_order' 	=> esc_html__( 'Menu Order', 'TKV-addons' ),
				'count' 		=> esc_html__( 'Product Counts', 'TKV-addons' ),
			),
			'value' => ''
		) );

		$this->add_control( array(
			'type' => 'text',
			'name' => 'include',
			'label' => esc_html__( 'Include', 'TKV-addons' ),
			'description' => esc_html__( 'Enter product category name, separate by commas.', 'TKV-addons' ),
		) );

		$this->add_control( array(
			'type' => 'text',
			'name' => 'exclude',
			'label' => esc_html__( 'Exclude', 'TKV-addons' ),
			'description' => esc_html__( 'Enter product category ids, separate by commas.', 'TKV-addons' ),
		) );

		$this->add_control( array(
			'type' => 'text',
			'name' => 'limit',
			'label' => esc_html__( 'Limit', 'TKV-addons' ),
		) );

		$this->add_control( array(
			'type' => 'checkbox',
			'name' => 'hide_empty',
			'options' => array(
				'1'  => esc_html__( 'Hide empty categories', 'TKV-addons' ),
			),
		) );

		$this->add_control( array(
			'type' => 'checkbox',
			'name' => 'hide_title',
			'options' => array(
				'1'  => esc_html__( 'Hide Title', 'TKV-addons' ),
			),
		) );

		$this->add_control( array(
			'type' => 'checkbox',
			'name' => 'all_cats',
			'class' => 'TKV-menu-item-taxonomy-brand TKV-hidden',
			'options' => array(
				'1'  => esc_html__( 'All Brands', 'TKV-addons' ),
			),
		) );
	}

	/**
	 * Get categories
	 *
	 * @return option
	 */
	public function get_taxonomy() {
		$options = array( 'product_cat' => esc_html__( 'Product Category', 'TKV-addons' ) );

		if ( get_option( 'TKV_product_brand', 'yes' ) == 'yes' ) {
			$taxonomy_brand = array( 'product_brand' => esc_html__( 'Product Brand', 'TKV-addons' ) );
			$options = $options + $taxonomy_brand;
		}

		return $options;
	}
}