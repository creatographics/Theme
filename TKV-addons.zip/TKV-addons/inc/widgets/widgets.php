<?php
/**
 * Load and register widgets
 *
 * @package TKV
 */

namespace TKV\Addons;
/**
 * TKV theme init
 */
class Widgets {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		// Include plugin files
		add_action( 'widgets_init', array( $this, 'register_widgets' ) );
	}


	/**
	 * Register widgets
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function register_widgets() {
		$this->includes();
		$this->add_actions();
	}

	/**
	 * Include Files
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function includes() {
		\TKV\Addons\Auto_Loader::register( [
			'TKV\Addons\Widgets\User_Bio'    => TKV_ADDONS_DIR . 'inc/widgets/user-bio.php',
			'TKV\Addons\Widgets\Posts_Slider'    => TKV_ADDONS_DIR . 'inc/widgets/posts-slider.php',
			'TKV\Addons\Widgets\Social_Links'    => TKV_ADDONS_DIR . 'inc/widgets/socials.php',
			'TKV\Addons\Widgets\Instagram_Widget'    => TKV_ADDONS_DIR . 'inc/widgets/instagram.php',
			'TKV\Addons\Widgets\Newsletter_Widget'    => TKV_ADDONS_DIR . 'inc/widgets/newsletter.php',
			'TKV\Addons\Widgets\Popular_Posts_Widget'    => TKV_ADDONS_DIR . 'inc/widgets/popular-posts.php',
			'TKV\Addons\Widgets\IconBox'    => TKV_ADDONS_DIR . 'inc/widgets/icon-box/icon-box.php',
		] );
	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function add_actions() {
		register_widget( new \TKV\Addons\Widgets\User_Bio() );
		register_widget( new \TKV\Addons\Widgets\Posts_Slider() );
		register_widget( new \TKV\Addons\Widgets\Social_Links() );
		register_widget( new \TKV\Addons\Widgets\Instagram_Widget() );
		register_widget( new \TKV\Addons\Widgets\Newsletter_Widget() );
		register_widget( new \TKV\Addons\Widgets\Popular_Posts_Widget() );
		register_widget( new \TKV\Addons\Widgets\IconBox() );
	}
}