<?php
/**
 * Register template builder
 */

namespace TKV\Addons\Elementor\Builder;

class Post_Type {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;


	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	const POST_TYPE     = 'TKV_builder';
	const OPTION_NAME   = 'TKV_builder';
	const TAXONOMY_TYPE     = 'TKV_builder_type';

	/**
	 * Class constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_admin_menu' ), 50 );

		// Make sure the post types are loaded for imports
		add_action( 'import_start', array( $this, 'register_post_type' ) );

		// Register custom post type and custom taxonomy
		$this->register_post_type();

		// Register custom post type and custom taxonomy
		$this->register_taxonomy();

		add_action('admin_init', array( $this, 'create_terms' ));

	}

	/**
	 * Register portfolio post type
	 */
	public function register_post_type() {
		// Template Builder
		$labels = array(
			'name'               => esc_html__( 'TKV Template Builder', 'TKV-addons' ),
			'singular_name'      => esc_html__( 'TKV Template', 'TKV-addons' ),
			'menu_name'          => esc_html__( 'TKV Template', 'TKV-addons' ),
			'name_admin_bar'     => esc_html__( 'TKV Template', 'TKV-addons' ),
			'add_new'            => esc_html__( 'Add New', 'TKV-addons' ),
			'add_new_item'       => esc_html__( 'Add New Template', 'TKV-addons' ),
			'new_item'           => esc_html__( 'New Template', 'TKV-addons' ),
			'edit_item'          => esc_html__( 'Edit Template', 'TKV-addons' ),
			'view_item'          => esc_html__( 'View Template', 'TKV-addons' ),
			'all_items'          => esc_html__( 'All Elementor', 'TKV-addons' ),
			'search_items'       => esc_html__( 'Search Templates', 'TKV-addons' ),
			'parent_item_colon'  => esc_html__( 'Parent Template:', 'TKV-addons' ),
			'not_found'          => esc_html__( 'No Templates found.', 'TKV-addons' ),
			'not_found_in_trash' => esc_html__( 'No Templates found in Trash.', 'TKV-addons' ),
		);

		$args = array(
			'labels'              => $labels,
			'public'              => true,
			'rewrite'             => false,
			'show_ui'             => true,
			'show_in_menu'        => false,
			'show_in_nav_menus'   => false,
			'exclude_from_search' => true,
			'capability_type'     => 'post',
			'hierarchical'        => false,
			'menu_icon'           => 'dashicons-editor-kitchensink',
			'supports'            => array( 'title', 'editor', 'elementor' ),
		);

		if ( ! post_type_exists( self::POST_TYPE ) ) {
			register_post_type( self::POST_TYPE, $args );
		}
	}

	public function register_admin_menu() {
		add_submenu_page(
			'edit.php?post_type=elementor_library',
			esc_html__( 'TKV Builder', 'TKV-addons' ),
			esc_html__( 'TKV Builder', 'TKV-addons' ),
			'edit_pages',
			'edit.php?post_type=' . self::POST_TYPE . ''
		);

	}

	/**
	 * Register core taxonomies.
	 */
	public function register_taxonomy() {
		if ( taxonomy_exists( self::TAXONOMY_TYPE ) ) {
			return;
		}

		register_taxonomy(
			self::TAXONOMY_TYPE,
			array( self::POST_TYPE ),
			array(
				'hierarchical'      => false,
				'show_ui'           => false,
				'show_in_nav_menus' => false,
				'query_var'         => is_admin(),
				'rewrite'           => false,
				'public'            => false,
				'label'             => _x( 'TKV Builder Type', 'Taxonomy name', 'TKV-addons' ),
			)
		);
	}

	public function create_terms() {
		$terms = array(
			'shop',
			'product',
			'archive',
			'enable'
		);

		foreach ( $terms as $term ) {
			if ( ! get_term_by( 'name', $term, self::TAXONOMY_TYPE ) ) { // @codingStandardsIgnoreLine.
				wp_insert_term( $term, self::TAXONOMY_TYPE );
			}
		}

	}

}