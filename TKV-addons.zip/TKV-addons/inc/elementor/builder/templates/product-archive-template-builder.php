<?php
/**
 * The Template for displaying catalog page
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

do_action( 'TKV_woocommerce_archive_product_content' );
