<?php
namespace TKV\Addons\Elementor\Builder\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Product_Sku extends Widget_Base {

	use \TKV\Addons\Elementor\Builder\Traits\Product_Id_Trait;

	public function get_name() {
		return 'TKV-wc-product-sku';
	}

	public function get_title() {
		return esc_html__( '[TKV] Product Sku', 'TKV-addons' );
	}

	public function get_icon() {
		return 'eicon-product-meta';
	}

	public function get_categories() {
		return ['TKV-wc-addons'];
	}

	public function get_keywords() {
		return [ 'woocommerce', 'shop', 'store', 'sku', 'taxonomy', 'product' ];
	}

	public function get_style_depends() {
		return [ 'TKV-single-product' ];
	}

	/**
	 * Register heading widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 3.1.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_title',
			[
				'label' => esc_html__( 'Product Sku', 'TKV-addons' ),
			]
		);

		$this->add_control(
			'sku_caption',
			[
				'label' => esc_html__( 'Caption', 'TKV-addons' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Sku:', 'TKV-addons' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label' => esc_html__( 'Alignment', 'TKV-addons' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'TKV-addons' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'TKV-addons' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'TKV-addons' ),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'TKV-addons' ),
						'icon' => 'eicon-text-align-justify',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_sku_style',
			[
				'label' => esc_html__( 'Product Sku', 'TKV-addons' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'category_color',
			[
				'label' => esc_html__( 'Text Color', 'TKV-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .product-sku a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'category_typography',
				'selector' => '{{WRAPPER}} .product-sku, {{WRAPPER}} .product-sku a',
			]
		);

		$this->add_control(
			'section_category_caption_style',
			[
				'label' => __( 'Caption', 'TKV-addons' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'caption_color',
			[
				'label' => esc_html__( 'Text Color', 'TKV-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .product-sku__caption' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'caption_typography',
				'selector' => '{{WRAPPER}} .product-sku__caption',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render heading widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		global $product;

		$product = $this->get_product();

		if ( ! $product ) {
			return;
		}

		if( ! $product->get_sku() ) {
			return;
		}

		$this->add_render_attribute( 'title', 'class', 'product-sku' );

		?>
		<div <?php echo $this->get_render_attribute_string( 'title' ); ?>>
			<span class="product-sku__caption"><?php echo ! empty( $settings['sku_caption'] ) ? $settings['sku_caption'] : esc_html__('Sku:', 'TKV');?></span>
			<span class="product-sku__name"><?php echo esc_html(  $product->get_sku() ); ?></a>
		</div>
		<?php
	}
}
