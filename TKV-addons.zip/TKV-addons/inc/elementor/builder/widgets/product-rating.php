<?php
namespace TKV\Addons\Elementor\Builder\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Product_Rating extends Widget_Base {

	use \TKV\Addons\Elementor\Builder\Traits\Product_Id_Trait;

	public function get_name() {
		return 'TKV-wc-product-rating';
	}

	public function get_title() {
		return esc_html__( '[TKV] Product Rating', 'TKV-addons' );
	}

	public function get_icon() {
		return 'eicon-product-rating';
	}

	public function get_categories() {
		return ['TKV-wc-addons'];
	}

	public function get_keywords() {
		return [ 'woocommerce', 'shop', 'store', 'rating', 'review', 'comments', 'stars', 'product' ];
	}

	public function get_style_depends() {
		return [ 'TKV-single-product' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_product_rating_style',
			[
				'label' => esc_html__( 'Style', 'TKV-addons' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'star_color',
			[
				'label' => esc_html__( 'Star Color', 'TKV-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woocommerce-product-rating .star-rating .user-rating' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'empty_star_color',
			[
				'label' => esc_html__( 'Empty Star Color', 'TKV-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woocommerce-product-rating .star-rating .max-rating' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'link_color',
			[
				'label' => esc_html__( 'Link Color', 'TKV-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woocommerce-product-rating .woocommerce-review-link' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'selector' => '{{WRAPPER}} .woocommerce-product-rating .woocommerce-review-link',
			]
		);

		$this->add_control(
			'star_size',
			[
				'label' => esc_html__( 'Star Size', 'TKV-addons' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => 'em',
				],
				'range' => [
					'em' => [
						'min' => 0,
						'max' => 4,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .woocommerce-product-rating .star-rating' => 'font-size: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'star_width',
			[
				'label' => esc_html__( 'Star Width', 'TKV-addons' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => 'px',
				],
				'range' => [
					'em' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .woocommerce-product-rating .star-rating' => 'width: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'star_height',
			[
				'label' => esc_html__( 'Star Height', 'TKV-addons' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .woocommerce-product-rating .star-rating' => 'height: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'heading_review_style',
			[
				'label' => esc_html__( 'Write a Review', 'TKV-addons' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'write_a_review',
			[
				'label' => esc_html__( 'Enable', 'TKV-addons' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'TKV-addons' ),
				'label_off' => esc_html__( 'No', 'TKV-addons' ),
				'return_value' => 'yes',
				'default' => '',
			]
		);

		$this->add_control(
			'write_a_review_text',
			[
				'label' => __( 'Title', 'TKV-addons' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( 'Write a Review', 'TKV' ),
			]
		);

		$this->add_control(
			'write_a_review_spacing',
			[
				'label' => esc_html__( 'Spacing', 'TKV-addons' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => 'px',
				],
				'range' => [
					'em' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-products-rating--has-write .woocommerce-product-rating' => 'margin-right: {{SIZE}}{{UNIT}};padding-right: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'write_a_review_typography',
				'selector' => '{{WRAPPER}} .TKV-button.TKV-products-rating--has-write .woocommerce-review-link',
			]
		);

		$this->add_control(
			'write_a_review_color',
			[
				'label' => esc_html__( 'Border Color', 'TKV-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .TKV-products-rating--has-write .woocommerce-product-rating' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		global $product;
		$product = $this->get_product();

		if ( ! $product ) {
			return;
		}
		if ( function_exists('wc_review_ratings_enabled') && ! wc_review_ratings_enabled() ) {
			return;
		}

		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'wrapper', 'class', [
			'TKV-products-rating',
			$settings['write_a_review'] == 'yes' ? 'TKV-products-rating--has-write' : ''
		] );
		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<?php
			if (  \TKV\Addons\Elementor\Builder\Helper::is_elementor_editor_mode() ) {
				$original_post = $GLOBALS['post'];
				$GLOBALS['post'] = get_post( $product->get_id() );
				setup_postdata( $GLOBALS['post'] );
			}

			if( function_exists('woocommerce_template_single_rating') ) {
				woocommerce_template_single_rating();
			}

			if (  \TKV\Addons\Elementor\Builder\Helper::is_elementor_editor_mode() ) {
				$GLOBALS['post'] = $original_post;
			}
			if( $settings['write_a_review'] == 'yes' ) {
				$text = $settings['write_a_review_text'];
				$text = empty( $text ) ? esc_html__('Write a Review', 'TKV') : $text;
			?>
			<a href="#reviews" class="TKV-button TKV-button--subtle  TKV-button--color-black woocommerce-review-link">
				<span class="TKV-button__text"><?php echo $text ?></span>
			</a>
			<?php
			}
			?>
		</div>
		<?php
	}

	public function render_plain_content() {}

	public function get_group_name() {
		return 'woocommerce';
	}
}
