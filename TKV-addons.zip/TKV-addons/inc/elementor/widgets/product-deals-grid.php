<?php

namespace TKV\Addons\Elementor\Widgets;

use Elementor\Controls_Manager;
use TKV\Addons\Elementor\Base\Products_Widget_Base;
use TKV\Addons\Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Product Deals Grid widget
 */
class Product_Deals_Grid extends Products_Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'TKV-product-deals-grid';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( '[TKV] Product Deals Grid', 'TKV-addons' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'TKV-addons' ];
	}

	public function get_script_depends() {
		return [
			'TKV-coundown',
			'TKV-elementor-widgets'
		];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->section_content();
		$this->section_style();
	}

	// Tab Content
	protected function section_content() {
		$this->section_products_settings_controls();
		$this->section_pagination_settings_controls();
	}

	// Tab Style
	protected function section_style() {
		$this->section_product_style_controls();
	}

	protected function section_products_settings_controls() {
		$this->start_controls_section(
			'section_products',
			[ 'label' => esc_html__( 'Products', 'TKV-addons' ) ]
		);

		$this->add_control(
			'products_divider',
			[
				'label' => esc_html__( 'Products', 'TKV-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'limit',
			[
				'label'   => esc_html__( 'Total Products', 'TKV-addons' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 16,
				'min'     => 1,
				'max'     => 500,
				'step'    => 1,
			]
		);

		$this->add_control(
			'columns',
			[
				'label'     => esc_html__( 'Columns', 'TKV-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'1' => esc_html__( '1', 'TKV-addons' ),
					'2' => esc_html__( '2', 'TKV-addons' ),
					'3' => esc_html__( '3', 'TKV-addons' ),
					'4' => esc_html__( '4', 'TKV-addons' ),
					'5' => esc_html__( '5', 'TKV-addons' ),
					'6' => esc_html__( '6', 'TKV-addons' ),
				],
				'default'   => '4',
			]
		);

		$this->add_control(
			'type',
			[
				'label'     => esc_html__( 'Products', 'TKV-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'day'   => esc_html__( 'Deals of the day', 'TKV-addons' ),
					'week'  => esc_html__( 'Deals of the week', 'TKV-addons' ),
					'month' => esc_html__( 'Deals of the month', 'TKV-addons' ),
					'sale' => esc_html__( 'On Sale', 'TKV-addons' ),
					'deals' => esc_html__( 'Product Deals', 'TKV-addons' ),
					'recent' => esc_html__( 'Recent Products', 'TKV-addons' ),
				],
				'default'   => 'day',
				'toggle'    => false,
				'prefix_class' => 'TKV-product-deals__type-',
			]
		);

		$this->add_control(
			'orderby',
			[
				'label'     => esc_html__( 'Order By', 'TKV-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'menu_order' => __( 'Menu Order', 'TKV-addons' ),
					'date'       => __( 'Date', 'TKV-addons' ),
					'title'      => __( 'Title', 'TKV-addons' ),
					'price'      => __( 'Price', 'TKV-addons' ),
				],
				'default'   => 'menu_order',
			]
		);

		$this->add_control(
			'order',
			[
				'label'     => esc_html__( 'Order', 'TKV-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''     => esc_html__( 'Default', 'TKV-addons' ),
					'asc'  => esc_html__( 'Ascending', 'TKV-addons' ),
					'desc' => esc_html__( 'Descending', 'TKV-addons' ),
				],
				'default'   => '',
			]
		);

		$this->add_control(
			'product_outofstock',
			[
				'label'        => esc_html__( 'Show Out Of Stock Products', 'TKV-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'TKV-addons' ),
				'label_off'    => esc_html__( 'Hide', 'TKV-addons' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'product_cat',
			[
				'label'       => esc_html__( 'Product Categories', 'TKV-addons' ),
				'placeholder' => esc_html__( 'Click here and start typing...', 'TKV-addons' ),
				'type'        => 'TKV-autocomplete',
				'default'     => '',
				'label_block' => true,
				'multiple'    => true,
				'source'      => 'product_cat',
				'sortable'    => true,

			]
		);

		$this->add_control(
			'product_tag',
			[
				'label'       => esc_html__( 'Product Tags', 'TKV-addons' ),
				'placeholder' => esc_html__( 'Click here and start typing...', 'TKV-addons' ),
				'type'        => 'TKV-autocomplete',
				'default'     => '',
				'label_block' => true,
				'multiple'    => true,
				'source'      => 'product_tag',
				'sortable'    => true,

			]
		);

		$this->add_control(
			'product_brand',
			[
				'label'       => esc_html__( 'Product Brands', 'TKV-addons' ),
				'placeholder' => esc_html__( 'Click here and start typing...', 'TKV-addons' ),
				'type'        => 'TKV-autocomplete',
				'default'     => '',
				'label_block' => true,
				'multiple'    => true,
				'source'      => 'product_brand',
				'sortable'    => true,

			]
		);

		$this->end_controls_section();
	}

	protected function section_pagination_settings_controls() {
		$this->start_controls_section(
			'section_pagination_settings',
			[ 'label' => esc_html__( 'Pagination', 'TKV-addons' ) ]
		);

		$this->add_control(
			'pagination',
			[
				'label'   => esc_html__( 'Pagination', 'TKV-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'none'     => esc_html__( 'None', 'TKV-addons' ),
					'numberic' => esc_html__( 'Numberic', 'TKV-addons' ),
				],
				'default'            => 'none',
			]
		);

		$this->end_controls_section();
	}

	protected function section_product_style_controls() {
		$this->start_controls_section(
			'section_style_product',
			[
				'label' => esc_html__( 'Product', 'TKV-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'hide_progress_bar',
			[
				'label'        => esc_html__( 'Hide Progress Bar', 'TKV-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_off'    => __( 'Off', 'TKV-addons' ),
				'label_on'     => __( 'On', 'TKV-addons' ),
				'return_value' => 'yes',
				'default'      => 'no',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render icon box widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$classes = [
			'TKV-product-deals-grid TKV-product-deals',
		];

		$attr = [
			'type' 			=> $settings['type'],
			'orderby'  			=> $settings['orderby'],
			'order'    			=> $settings['order'],
			'category'    		=> $settings['product_cat'],
			'tag'    			=> $settings['product_tag'],
			'product_brands'    => $settings['product_brand'],
			'limit'    			=> $settings['limit'],
			'columns'    		=> $settings['columns'],
			'paginate'			=> true,
		];

		if ( isset( $settings['product_outofstock'] ) && empty( $settings['product_outofstock'] ) ) {
			$attr['product_outofstock'] = $settings['product_outofstock'];
		}

		$results = Utils::products_shortcode( $attr );
		if ( ! $results ) {
			return;
		}

		$results_ids = ! empty($results['ids']) ? $results['ids'] : 0;

		$this->add_render_attribute( 'wrapper', 'class', $classes );

		echo '<div ' . $this->get_render_attribute_string( 'wrapper' ) .'>';

		wc_setup_loop(
			array(
				'columns'      => $settings['columns']
			)
		);

		Utils::get_template_loop( $results_ids );

		echo '</div>';
		if ( $settings['pagination'] == 'numberic' ) {
			self::get_pagination( $results['total_pages'], $results['current_page'] );
		}
	}

	/**
	 * Products pagination.
	 */
	public static function get_pagination( $total_pages, $current_page ) {
		echo '<nav class="woocommerce-pagination">';
		echo paginate_links(
			array( // WPCS: XSS ok.
				'base'      => esc_url_raw( add_query_arg( 'product-page', '%#%', false ) ),
				'format'    => '?product-page=%#%',
				'add_args'  => false,
				'current'   => max( 1, $current_page ),
				'total'     => $total_pages,
				'prev_text' => \TKV\Addons\Helper::get_svg( 'left', 'ui', 'class=TKV-pagination__arrow' ),
				'next_text' =>\TKV\Addons\Helper::get_svg( 'right', 'ui', 'class=TKV-pagination__arrow' ),
				'type'      => 'list',
			)
		);
		echo '</nav>';
	}


}