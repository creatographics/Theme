<?php
namespace TKV\Addons\Elementor\Widgets\Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use TKV\Addons\Elementor\Utils;
use TKV\Addons\Helper;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Border;

trait Button_Trait {
	/**
	 * Register controls for button controls
	 *
	 * @param array $args
	 */
	protected function register_button_content_controls($args = [], \Elementor\Repeater $repeater = null) {
		$instance = empty( $repeater ) ? $this : $repeater;

		$default_args = [
			'prefix'    => 'primary',
			'button_text_default'     => '',
			'button_text_label'     => __( 'Text', 'TKV-addons' ),
			'button_text_link'     => __( 'Link', 'TKV-addons'),
			'button_icon' => false,
			'button_text_label_mobile'     => '',
			'section_condition' => [],
		];

		$args = wp_parse_args( $args, $default_args);
		$prefix = $args['prefix'];
		$instance->add_control(
			$prefix . '_button_text',
			[
				'label' => $args['button_text_label'],
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => $args['button_text_default'],
				'condition' => $args['section_condition'],
			]
		);

		if( $args['button_text_label_mobile'] ) {
			$instance->add_control(
				$prefix . '_mobile_button_text',
				[
					'label' => $args['button_text_label_mobile'],
					'type' => Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'default' => '',
					'condition' => $args['section_condition'],
				]
			);
		}

		$instance->add_control(
			$prefix . '_button_link',
			[
				'label' => $args['button_text_link'],
				'type' => Controls_Manager::URL,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => '',
				],
				'condition' => $args['section_condition'],
			]
		);

		if( $args['button_icon'] ) {
			$instance->add_control(
				$prefix . '_button_selected_icon',
				[
					'label' => esc_html__( 'Icon', 'TKV-addons' ),
					'type' => Controls_Manager::ICONS,
					'fa4compatibility' => 'icon',
					'skin' => 'inline',
					'label_block' => false,
					'condition' => $args['section_condition'],
				]
			);

			$instance->add_control(
				$args['prefix'] .  '_button_icon_align',
				[
					'label' => esc_html__( 'Icon Position', 'TKV-addons' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'right',
					'options' => [
						'left' => esc_html__( 'Before', 'TKV-addons' ),
						'right' => esc_html__( 'After', 'TKV-addons' ),
					],
					'condition' =>  wp_parse_args( [ $prefix .'_button_selected_icon[value]!' => '' ], $args['section_condition'] ),
				]
			);

			$instance->add_control(
				$args['prefix'] . '_button_icon_indent',
				[
					'label' => esc_html__( 'Icon Spacing', 'TKV-addons' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'max' => 50,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .TKV-button-' . $args['prefix'] . ' .TKV-align-icon-left + .TKV-button__text' => 'padding-left: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .TKV-button-' . $args['prefix'] . ' .TKV-align-icon-right + .TKV-button__text' => 'padding-right: {{SIZE}}{{UNIT}};',
					],
					'condition' =>  wp_parse_args( [ $prefix .'_button_selected_icon[value]!' => '' ], $args['section_condition'] ),
				]
			);
		}

	}

	/**
	 * Register controls for button style
	 *
	 * @param array $args
	 */
	protected function register_button_style_controls( $args = [] ) {
		$default_args = [
			'prefix'    => 'primary',
			'skin'     => 'base',
			'shape' => 'default',
			'size'      => 'medium',
			'section_condition' => [],
		];

		$args = wp_parse_args( $args, $default_args);
		$this->add_control(
			$args['prefix'] . '_button_skin',
			[
				'label' => __( 'Skin', 'TKV-addons' ),
				'type' => Controls_Manager::SELECT,
				'default' => $args['skin'],
				'options' => [
					'base'   	=> __( 'Base', 'TKV-addons' ),
					'raised' 	=> __( 'Raised', 'TKV-addons' ),
					'smooth' 	=> __( 'Smooth', 'TKV-addons' ),
					'ghost'  	=> __( 'Ghost', 'TKV-addons' ),
					'subtle' 	=> __( 'Subtle', 'TKV-addons' ),
					'text'   	=> __( 'Text', 'TKV-addons' ),
				],
				'condition' => $args['section_condition'],
			]
		);

		$this->add_control(
			$args['prefix'] . '_button_shape',
			[
				'label' => __( 'Shape', 'TKV-addons' ),
				'type' => Controls_Manager::SELECT,
				'default' => $args['shape'],
				'options' => [
					'default' => __( 'Default', 'TKV-addons' ),
					'sharp'   => __( 'Sharp', 'TKV-addons' ),
					'round'   => __( 'Round', 'TKV-addons' ),
					'circle'  => __( 'Circle', 'TKV-addons' ),
				],
				'condition' => $args['section_condition'],
			]
		);

		$this->add_control(
			$args['prefix'] . '_button_size',
			[
				'label' => __( 'Size', 'TKV-addons' ),
				'type' => Controls_Manager::SELECT,
				'default' => $args['size'],
				'options' => [
					'small'  => __( 'Small', 'TKV-addons' ),
					'medium' => __( 'Medium', 'TKV-addons' ),
					'large'  => __( 'Large', 'TKV-addons' ),
				],
				'condition' => $args['section_condition'],
			]
		);


		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => $args['prefix'] . '_button_typography',
				'selector' => '{{WRAPPER}} .TKV-button-' . $args['prefix'],
				'condition' => $args['section_condition'],
			]
		);

		$this->add_control(
			$args['prefix'] . '_button_options',
			[
				'label'        => __( 'Extra Options', 'TKV-addons' ),
				'type'         => Controls_Manager::POPOVER_TOGGLE,
				'label_off'    => __( 'Default', 'TKV-addons' ),
				'label_on'     => __( 'Custom', 'TKV-addons' ),
				'return_value' => 'yes',
				'condition' => $args['section_condition'],
			]
		);

		$this->start_popover();

		$this->add_responsive_control(
			$args['prefix'] . '_button_padding',
			[
				'label'      => esc_html__( 'Padding', 'TKV-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'default'    => [],
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .TKV-button-' . $args['prefix'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			$args['prefix'] . '_button_width',
			[
				'label'     => esc_html__( 'Width', 'TKV-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'size_units' => [ 'px','%' ],
				'selectors' => [
					'{{WRAPPER}} .TKV-button-' . $args['prefix'] => 'min-width: {{SIZE}}{{UNIT}};',
				],
				'condition' => $args['section_condition'],
			]

		);

		$this->add_responsive_control(
			$args['prefix'] . '_button_height',
			[
				'label'     => esc_html__( 'Height', 'TKV-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-button-' . $args['prefix'] => 'line-height: {{SIZE}}{{UNIT}};',
				],
				'condition' => $args['section_condition'],
			]

		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => $args['prefix'] . '_button_border',
				'label' => __( 'Border', 'TKV-addons' ),
				'selector' => '{{WRAPPER}} .TKV-button-' . $args['prefix'],
				'condition' => $args['section_condition'],
			]
		);

		$this->add_responsive_control(
			$args['prefix'] . '_button_border_radius',
			[
				'label'      => __( 'Border Radius', 'TKV-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .TKV-button-' . $args['prefix'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => $args['section_condition'],
			]
		);

		$this->start_controls_tabs(
			$args['prefix'] . '_button_style_tabs',
			[
				'condition' => $args['section_condition'],
			]
		);

		$this->start_controls_tab(
			$args['prefix'] . '_button_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'TKV-addons' ),
				'condition' => $args['section_condition'],
			]
		);

		$this->add_responsive_control(
			$args['prefix'] . '_button_background_color',
			[
				'label'      => esc_html__( 'Background Color', 'TKV-addons' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} .TKV-button-'  . $args['prefix'] => 'background-color: {{VALUE}}',
				],
				'condition' => $args['section_condition'],
			]
		);

		$this->add_responsive_control(
			$args['prefix'] . '_button_color',
			[
				'label'      => esc_html__( 'Color', 'TKV-addons' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} .TKV-button-'  . $args['prefix'] => 'color: {{VALUE}}',
				],
				'condition' => $args['section_condition'],
			]
		);

		$this->add_responsive_control(
			$args['prefix'] . '_button_box_shadow_color',
			[
				'label' => __( 'Box Shadow Color', 'TKV-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .TKV-button-'  . $args['prefix'] => '--mt-color__primary--box-shadow: {{VALUE}}',
				],
				'condition' => $args['section_condition'],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			$args['prefix'] . '_button_style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'TKV-addons' ),
				'condition' => $args['section_condition'],
			]
		);

			$this->add_responsive_control(
				$args['prefix'] . '_button_hover_background_color',
				[
					'label' => __( 'Background Color', 'TKV-addons' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .TKV-button-'  . $args['prefix'] .':hover' => 'background-color: {{VALUE}};',
					],
					'condition' => $args['section_condition'],
				]
			);

			$this->add_responsive_control(
				$args['prefix'] . '_button_hover_color',
				[
					'label' => __( 'Color', 'TKV-addons' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .TKV-button-'  . $args['prefix'] .':hover' => 'color: {{VALUE}};',
					],
					'condition' => $args['section_condition'],
				]
			);

			$this->add_responsive_control(
				$args['prefix'] . '_button_box_shadow_color_hover',
				[
					'label' => __( 'Box Shadow Hover Color', 'TKV-addons' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .TKV-button-'  . $args['prefix'] .':hover' => '--mt-color__primary--box-shadow: {{VALUE}}',
					],
					'condition' => $args['section_condition'],
				]
			);


		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_popover();

	}

	/**
	  * Render button widget output on the frontend.
	 *
	 * @param \Elementor\Widget_Base|null $instance
	 * @param array $settings
	 */
	protected function render_button ($prefix = 'primary', Widget_Base $instance = null, $fixed_tag = false) {
		if ( empty( $instance ) ) {
			$instance = $this;
		}

		$settings = $this->get_settings_for_display();
		$settings['prefix'] = $prefix;
		if( (empty($settings[$prefix. '_button_selected_icon']) || empty( $settings[$prefix. '_button_selected_icon']['value'] )) && empty( $settings[$prefix . '_button_text'] ) && empty( $settings[$prefix . '_mobile_button_text'] ) ) {
			return;
		}

		$atts_name = $prefix . '_button';

		$instance->add_render_attribute( $atts_name , 'class', 'TKV-button' );
		$instance->add_render_attribute( $atts_name , 'class', 'TKV-button-' . $prefix );
		if( isset( $settings['classes'] ) ) {
			$instance->add_render_attribute( $atts_name , 'class', $settings['classes'] );
		}
		$instance->add_render_attribute( $atts_name , 'class', ' TKV-button--' . $settings[$prefix . '_button_skin'] );

		if( in_array( $settings[$prefix . '_button_skin'], array('subtle', 'text', 'ghost') ) ) {
			$instance->add_render_attribute( $atts_name , 'class', ' TKV-button--color-black');
		}

		if( $settings[$prefix . '_button_size'] !== 'normal' ) {
			$instance->add_render_attribute( $atts_name, 'class', ' TKV-button--' . $settings[$prefix . '_button_size'] );
		}

		if( $settings[$prefix . '_button_shape'] !== 'default' ) {
			$instance->add_render_attribute( $atts_name , 'class', ' TKV-shape--' . $settings[$prefix . '_button_shape'] );
		}

		$tag = 'a';

		if ( isset( $settings['button_link_type'] ) && $settings['button_link_type'] == 'all' && empty( $settings['second_button_text'] ) ) {
			$tag = 'span';
		} else {
			if ( ! empty( $settings[$prefix . '_button_link']['url'] ) ) {
				$instance->add_link_attributes( $atts_name, $settings[$prefix . '_button_link'] );
			}
		}

		?>
		<<?php echo esc_attr( $tag ) ?> <?php $instance->print_render_attribute_string( $atts_name ); ?>>
			<?php $this->render_text( $settings, $instance  ); ?>
		</<?php echo esc_attr( $tag ) ?>>
		<?php

	}

	/**
	 * Render button text.
	 *
	 * Render button widget text.
	 *
	 * @param \Elementor\Widget_Base|null $instance
	 * @param array $settings
	 *
	 */
	protected function render_text($settings, $instance) {
		$prefix = $settings['prefix'];

		$instance->add_render_attribute( [
			$prefix . '_button_icon-align' => [
				'class' => [
					'TKV-button__icon TKV-svg-icon',
				],
			],
		] );

		if( isset($settings[$prefix . '_button_icon_align'] ) ) {
			$instance->add_render_attribute( [
				$prefix . '_button_icon-align' => [
					'class' => [
						'TKV-align-icon-' . $settings[$prefix . '_button_icon_align'],
					],
				],
			] );
		}

		?>
		<?php if ( isset($settings[$prefix . '_button_selected_icon']) && ! empty( $settings[$prefix. '_button_selected_icon']['value'] ) ) : ?>
			<span <?php $instance->print_render_attribute_string( $prefix . '_button_icon-align' ); ?>>
				<?php Icons_Manager::render_icon( $settings[$prefix . '_button_selected_icon'], [ 'aria-hidden' => 'true' ] ); ?>
			</span>
		<?php endif; ?>
		<?php if ( isset($settings[$prefix . '_mobile_button_text']) && ! empty( $settings[$prefix . '_mobile_button_text']) ) : ?>
			<span class="TKV-button__text TKV-button__text_mobile"><?php echo $settings[$prefix . '_mobile_button_text']; ?></span>
		<?php endif; ?>
		<?php if ( isset($settings[$prefix . '_button_text']) && ! empty( $settings[$prefix . '_button_text']) ) : ?>
			<span class="TKV-button__text"><?php echo $settings[$prefix . '_button_text']; ?></span>
		<?php endif; ?>
		<?php
	}
}