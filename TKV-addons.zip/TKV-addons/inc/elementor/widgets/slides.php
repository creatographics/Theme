<?php

namespace TKV\Addons\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Widget_Base;
use Elementor\Core\Breakpoints\Manager as Breakpoints_Manager;
use Elementor\Utils;
use Elementor\Icons_Manager;
use \TKV\Addons\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Slides widget
 */
class Slides extends Widget_Base {
	use \TKV\Addons\Elementor\Widgets\Traits\Button_Trait;

	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'TKV-slides';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( '[TKV] Slides', 'TKV-addons' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-post-slider';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'TKV-addons' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->section_content();
		$this->section_style();
	}

	// Tab Content
	protected function section_content() {
		$this->section_content_slides();
		$this->section_content_option();
	}

	protected function section_content_slides() {
		$this->start_controls_section(
			'section_slides',
			[
				'label' => esc_html__( 'Slides', 'TKV-addons' ),
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->start_controls_tabs( 'slides_repeater' );


		$repeater->start_controls_tab( 'text_content', [ 'label' => esc_html__( 'Content', 'TKV-addons' ) ] );

		$repeater->add_control(
			'subtitle_type',
			[
				'label'       => esc_html__( 'SubTitle Type', 'TKV-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'text'   => esc_html__( 'Text', 'TKV-addons' ),
					'svg' 	 => esc_html__( 'SVG Icon', 'TKV-addons' ),
					'image'  => esc_html__( 'Image', 'TKV-addons' ),
					'external' 	=> esc_html__( 'External', 'TKV-addons' ),
				],
				'default' => 'text',
			]
		);

		$repeater->add_control(
			'subtitle',
			[
				'label'       => esc_html__( 'SubTitle', 'TKV-addons' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'label_block' => true,
				'conditions' => [
					'terms' => [
						[
							'name'  => 'subtitle_type',
							'value' => 'text',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'subtitle_icon',
			[
				'label' => __( 'SubTitle', 'TKV-addons' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fa fa-star',
					'library' => 'fa-solid',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'subtitle_type',
							'value' => 'svg',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'subtitle_image',
			[
				'label' => __( 'SubTitle', 'TKV-addons' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'subtitle_type',
							'value' => 'image',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'subtitle_external_url',
			[
				'label' => esc_html__( 'External URL', 'TKV-addons' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic' => [
					'active' => true,
				],
				'conditions' => [
					'terms' => [
						[
							'name' => 'subtitle_type',
							'value' => 'external',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'TKV-addons' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Slide Title', 'TKV-addons' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'before_description',
			[
				'label'       => esc_html__( 'Before Description', 'TKV-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'TKV-addons' ),
				'type'    => Controls_Manager::TEXTAREA,
			]
		);

		$repeater->add_control(
			'after_description',
			[
				'label'       => esc_html__( 'After Description', 'TKV-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$controls = [
			'button_text_default' => __( 'Shop Now', 'TKV-addons' ),
			'button_text_label' => __( 'Primary Button Text', 'TKV-addons' ),
			'button_text_link' => __( 'Primary Button Link', 'TKV-addons' )
		];

		$this->register_button_content_controls( $controls, $repeater );

		$repeater->add_control(
			'button_link_type',
			[
				'label'   => esc_html__( 'Apply Primary Link On', 'TKV-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'only' => esc_html__( 'Button Only', 'TKV-addons' ),
					'slide'  => esc_html__( 'Whole Slide', 'TKV-addons' ),
				],
				'default' => 'only',
				'conditions' => [
					'terms' => [
						[
							'name' => 'primary_button_link[url]',
							'operator' => '!=',
							'value' => '',
						],
					],
				],
			]
		);

		$controls_second = [
			'prefix'			=> 'second',
			'button_text_label' => __( 'Secondary Button Text', 'TKV-addons' ),
			'button_text_link' => __( 'Secondary Button Link', 'TKV-addons' )
		];

		$this->register_button_content_controls( $controls_second, $repeater );

		$repeater->add_control(
			'after_button',
			[
				'label'       => esc_html__( 'After Button', 'TKV-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_responsive_control(
			'image',
			[
				'label' => __( 'Image', 'TKV-addons' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}} .TKV-slide__image' => 'background-image: url("{{URL}}");',
				],
			]
		);

		$repeater->add_responsive_control(
			'image_background_size',
			[
				'label'     => esc_html__( 'Background Size', 'TKV-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					'' => esc_html__( 'Contain', 'TKV-addons' ),
					'cover'   => esc_html__( 'Cover', 'TKV-addons' ),
					'auto'    => esc_html__( 'Auto', 'TKV-addons' ),
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}} .TKV-slide__image' => 'background-size: {{VALUE}}',
				],
			]
		);

		$repeater->add_responsive_control(
			'image_background_position',
			[
				'label'     => esc_html__( 'Background Position', 'TKV-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''              => esc_html__( 'Default', 'TKV-addons' ),
					'left top'      => esc_html__( 'Left Top', 'TKV-addons' ),
					'left center'   => esc_html__( 'Left Center', 'TKV-addons' ),
					'left bottom'   => esc_html__( 'Left Bottom', 'TKV-addons' ),
					'right top'     => esc_html__( 'Right Top', 'TKV-addons' ),
					'right center'  => esc_html__( 'Right Center', 'TKV-addons' ),
					'right bottom'  => esc_html__( 'Right Bottom', 'TKV-addons' ),
					'center top'    => esc_html__( 'Center Top', 'TKV-addons' ),
					'center center' => esc_html__( 'Center Center', 'TKV-addons' ),
					'center bottom' => esc_html__( 'Center Bottom', 'TKV-addons' ),
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}} .TKV-slide__image' => 'background-position: {{VALUE}};',
				],

			]
		);

		$repeater->add_responsive_control(
			'image_background_repeat',
			[
				'label'     => esc_html__( 'Background Repeat', 'TKV-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'' => esc_html__( 'No Repeat', 'TKV-addons' ),
					'repeat'    => esc_html__( 'Repeat', 'TKV-addons' ),
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}} .TKV-slide__image' => 'background-repeat: {{VALUE}};',
				],

			]
		);

		$repeater->end_controls_tab();

		$repeater->start_controls_tab( 'background', [ 'label' => esc_html__( 'Background', 'TKV-addons' ) ] );

		$repeater->add_responsive_control(
			'banner_background_img',
			[
				'label'    => __( 'Background Image', 'TKV-addons' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => 'https://via.placeholder.com/800x400/f1f1f1?text=image',
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}}:not(.swiper-lazy)' => 'background-image: url("{{URL}}");',
				],
			]
		);

		$repeater->add_responsive_control(
			'background_size',
			[
				'label'     => esc_html__( 'Background Size', 'TKV-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'cover',
				'options'   => [
					'cover'   => esc_html__( 'Cover', 'TKV-addons' ),
					'contain' => esc_html__( 'Contain', 'TKV-addons' ),
					'auto'    => esc_html__( 'Auto', 'TKV-addons' ),
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}}' => 'background-size: {{VALUE}}',
				],
			]
		);

		$repeater->add_responsive_control(
			'background_position',
			[
				'label'     => esc_html__( 'Background Position', 'TKV-addons' ),
				'type'      => Controls_Manager::SELECT,
				'responsive' => true,
				'options'   => [
					''              => esc_html__( 'Default', 'TKV-addons' ),
					'left top'      => esc_html__( 'Left Top', 'TKV-addons' ),
					'left center'   => esc_html__( 'Left Center', 'TKV-addons' ),
					'left bottom'   => esc_html__( 'Left Bottom', 'TKV-addons' ),
					'right top'     => esc_html__( 'Right Top', 'TKV-addons' ),
					'right center'  => esc_html__( 'Right Center', 'TKV-addons' ),
					'right bottom'  => esc_html__( 'Right Bottom', 'TKV-addons' ),
					'center top'    => esc_html__( 'Center Top', 'TKV-addons' ),
					'center center' => esc_html__( 'Center Center', 'TKV-addons' ),
					'center bottom' => esc_html__( 'Center Bottom', 'TKV-addons' ),
					'initial' 		=> esc_html__( 'Custom', 'TKV-addons' ),
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}}' => 'background-position: {{VALUE}};',
				],

			]
		);

		$repeater->add_responsive_control(
			'background_position_x',
			[
				'label' => esc_html__( 'X Position', 'TKV-addons' ),
				'type' => Controls_Manager::SLIDER,
				'responsive' => true,
				'size_units' => [ 'px', 'em', '%', 'vw' ],
				'default' => [
					'unit' => 'px',
					'size' => 0,
				],
				'tablet_default' => [
					'unit' => 'px',
					'size' => 0,
				],
				'mobile_default' => [
					'unit' => 'px',
					'size' => 0,
				],
				'range' => [
					'px' => [
						'min' => -800,
						'max' => 800,
					],
					'em' => [
						'min' => -100,
						'max' => 100,
					],
					'%' => [
						'min' => -100,
						'max' => 100,
					],
					'vw' => [
						'min' => -100,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}}' => 'background-position: {{SIZE}}{{UNIT}} {{background_position_y.SIZE}}{{background_position_y.UNIT}}',
				],
				'condition' => [
					'background_position' => [ 'initial' ],
				],
				'required' => true,
			]
		);

		$repeater->add_responsive_control(
			'background_position_y',
			[
				'label' => esc_html__( 'Y Position', 'TKV-addons' ),
				'type' => Controls_Manager::SLIDER,
				'responsive' => true,
				'size_units' => [ 'px', 'em', '%', 'vh' ],
				'default' => [
					'unit' => 'px',
					'size' => 0,
				],
				'tablet_default' => [
					'unit' => 'px',
					'size' => 0,
				],
				'mobile_default' => [
					'unit' => 'px',
					'size' => 0,
				],
				'range' => [
					'px' => [
						'min' => -800,
						'max' => 800,
					],
					'em' => [
						'min' => -100,
						'max' => 100,
					],
					'%' => [
						'min' => -100,
						'max' => 100,
					],
					'vh' => [
						'min' => -100,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}}' => 'background-position: {{background_position_x.SIZE}}{{background_position_x.UNIT}} {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'background_position' => [ 'initial' ],
				],
				'required' => true,
			]
		);

		$repeater->add_responsive_control(
			'background_repeat',
			[
				'label'     => esc_html__( 'Background Repeat', 'TKV-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'repeat'    => esc_html__( 'Repeat', 'TKV-addons' ),
					'no-repeat' => esc_html__( 'No Repeat', 'TKV-addons' ),
				],
				'default'   => 'repeat',
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}}' => 'background-repeat: {{VALUE}};',
				],

			]
		);

		$repeater->add_responsive_control(
			'background_color',
			[
				'label'      => esc_html__( 'Background Color', 'TKV-addons' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}}' => 'background-color: {{VALUE}}',
				],
			]
		);

		$repeater->end_controls_tab();

		$repeater->start_controls_tab( 'style', [ 'label' => esc_html__( 'Style', 'TKV-addons' ) ] );

		$repeater->add_control(
			'custom_style',
			[
				'label'       => esc_html__( 'Custom', 'TKV-addons' ),
				'type'        => Controls_Manager::SWITCHER,
				'description' => esc_html__( 'Set custom style that will only affect this specific slide.', 'TKV-addons' ),
			]
		);

		$repeater->add_control(
			'subtitle_heading_name',
			[
				'label' => esc_html__( 'Subtitle', 'TKV-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'subtitle_image_mobile',
			[
				'label'       => esc_html__( 'Hide On Mobile', 'TKV-addons' ),
				'type'        => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Hide', 'TKV-addons' ),
				'label_off'    => __( 'Show', 'TKV-addons' ),
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				]
			]
		);

		$repeater->add_control(
			'subtitle_custom_color',
			[
				'label'      => esc_html__( 'Color', 'TKV-addons' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}} .slick-slide-inner .TKV-slide__subtitle' => 'color: {{VALUE}}',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
						[
							'name'  => 'subtitle_type',
							'value' => 'text',
						],
					],
				]
			]
		);

		$repeater->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'subtitle_custom_typography',
				'selector' => '{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}} .slick-slide-inner .TKV-slide__subtitle',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
						[
							'name'  => 'subtitle_type',
							'value' => 'text',
						],
					],
				],
			]
		);

		$repeater->add_responsive_control(
			'subtitle_custom_size',
			[
				'label' => __( 'Size', 'TKV-addons' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}} .slick-slide-inner .TKV-slide__subtitle svg' => 'width: {{size}}{{UNIT}};height: auto;',
					'{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}} .slick-slide-inner .TKV-slide__subtitle img' => 'max-width: {{size}}{{UNIT}};',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
						[
							'name' => 'subtitle_type',
							'operator' => '!=',
							'value' => 'text'
						],
					]
				]
			]
		);

		$repeater->add_control(
			'title_heading_name',
			[
				'label' => esc_html__( 'Title', 'TKV-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'title_custom_color',
			[
				'label'      => esc_html__( 'Color', 'TKV-addons' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}} .slick-slide-inner .TKV-slide__title' => 'color: {{VALUE}}',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'before_desc_heading_name',
			[
				'label' => esc_html__( 'Before Description', 'TKV-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'before_desc_custom_color',
			[
				'label'      => esc_html__( 'Color', 'TKV-addons' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}} .TKV-slide__before-description' => 'color: {{VALUE}}',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'desc_heading_name',
			[
				'label' => esc_html__( 'Description', 'TKV-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'content_custom_color',
			[
				'label'      => esc_html__( 'Color', 'TKV-addons' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}} .slick-slide-inner .TKV-slide__description' => 'color: {{VALUE}}',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				]
			]
		);

		$repeater->add_control(
			'after_desc_heading_name',
			[
				'label' => esc_html__( 'After Description', 'TKV-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'after_desc_custom_color',
			[
				'label'      => esc_html__( 'Color', 'TKV-addons' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}} .TKV-slide__after-description' => 'color: {{VALUE}}',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'custom_button_options',
			[
				'label'        => __( 'Primary Button', 'TKV-addons' ),
				'type'         => Controls_Manager::POPOVER_TOGGLE,
				'label_off'    => __( 'Default', 'TKV-addons' ),
				'label_on'     => __( 'Custom', 'TKV-addons' ),
				'return_value' => 'yes',
				'separator' => 'before',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->start_popover();

		$repeater->add_control(
			'custom_button_style_normal_heading',
			[
				'label' => esc_html__( 'Normal', 'TKV-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'custom_button_background_color',
			[
				'label'      => esc_html__( 'Background Color', 'TKV-addons' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor  {{CURRENT_ITEM}} .TKV-button-primary' => 'background-color: {{VALUE}}',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'custom_button_color',
			[
				'label'      => esc_html__( 'Color', 'TKV-addons' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor  {{CURRENT_ITEM}} .TKV-button-primary' => 'color: {{VALUE}}',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'custom_button_box_shadow_color',
			[
				'label' => __( 'Box Shadow Color', 'TKV-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor  {{CURRENT_ITEM}} .TKV-button-primary' => '--mt-color__primary--box-shadow: {{VALUE}}',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'custom_button_border_color',
			[
				'label' => __( 'Border Color', 'TKV-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor  {{CURRENT_ITEM}} .TKV-button-primary' => 'border-color: {{VALUE}};',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'custom_button_style_hover_heading',
			[
				'label' => esc_html__( 'Hover', 'TKV-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

			$repeater->add_control(
				'custom_button_hover_background_color',
				[
					'label' => __( 'Background Color', 'TKV-addons' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .TKV-slides-elementor  {{CURRENT_ITEM}} .TKV-button-primary:hover' => 'background-color: {{VALUE}};',
					],
					'conditions' => [
						'terms' => [
							[
								'name'  => 'custom_style',
								'value' => 'yes',
							],
						],
					],
				]
			);

			$repeater->add_control(
				'custom_button_hover_color',
				[
					'label' => __( 'Color', 'TKV-addons' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .TKV-slides-elementor  {{CURRENT_ITEM}} .TKV-button-primary:hover' => 'color: {{VALUE}};',
					],
					'conditions' => [
						'terms' => [
							[
								'name'  => 'custom_style',
								'value' => 'yes',
							],
						],
					],
				]
			);

			$repeater->add_control(
				'custom_button_box_shadow_color_hover',
				[
					'label' => __( 'Box Shadow Hover Color', 'TKV-addons' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .TKV-slides-elementor  {{CURRENT_ITEM}} .TKV-button-primary:hover' => '--mt-color__primary--box-shadow: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							[
								'name'  => 'custom_style',
								'value' => 'yes',
							],
						],
					],
				]
			);

			$repeater->add_control(
				'custom_button_hover_border_color',
				[
					'label' => __( 'Border Color', 'TKV-addons' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .TKV-slides-elementor  {{CURRENT_ITEM}} .TKV-button-primary:hover' => 'border-color: {{VALUE}};',
					],
					'conditions' => [
						'terms' => [
							[
								'name'  => 'custom_style',
								'value' => 'yes',
							],
						],
					],
				]
			);

		$repeater->end_popover();

		$repeater->add_control(
			'custom_button_second_options',
			[
				'label'        => __( 'Secondary Button', 'TKV-addons' ),
				'type'         => Controls_Manager::POPOVER_TOGGLE,
				'label_off'    => __( 'Default', 'TKV-addons' ),
				'label_on'     => __( 'Custom', 'TKV-addons' ),
				'return_value' => 'yes',
				'separator' => 'before',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->start_popover();

		$repeater->add_control(
			'custom_button_second_style_normal_heading',
			[
				'label' => esc_html__( 'Normal', 'TKV-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'custom_button_second_background_color',
			[
				'label'      => esc_html__( 'Background Color', 'TKV-addons' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor  {{CURRENT_ITEM}} .TKV-button-second' => 'background-color: {{VALUE}}',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'custom_button_second_color',
			[
				'label'      => esc_html__( 'Color', 'TKV-addons' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor  {{CURRENT_ITEM}} .TKV-button-second' => 'color: {{VALUE}}',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'custom_button_second_box_shadow_color',
			[
				'label' => __( 'Box Shadow Color', 'TKV-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor  {{CURRENT_ITEM}} .TKV-button-second' => '--mt-color__primary--box-shadow: {{VALUE}}',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'custom_button_second_border_color',
			[
				'label' => __( 'Border Color', 'TKV-addons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor  {{CURRENT_ITEM}} .TKV-button-second' => 'border-color: {{VALUE}};',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'custom_button_second_style_hover_heading',
			[
				'label' => esc_html__( 'Hover', 'TKV-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

			$repeater->add_control(
				'custom_button_second_hover_background_color',
				[
					'label' => __( 'Background Color', 'TKV-addons' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .TKV-slides-elementor  {{CURRENT_ITEM}} .TKV-button-second:hover' => 'background-color: {{VALUE}};',
					],
					'conditions' => [
						'terms' => [
							[
								'name'  => 'custom_style',
								'value' => 'yes',
							],
						],
					],
				]
			);

			$repeater->add_control(
				'custom_button_second_hover_color',
				[
					'label' => __( 'Color', 'TKV-addons' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .TKV-slides-elementor  {{CURRENT_ITEM}} .TKV-button-second:hover' => 'color: {{VALUE}};',
					],
					'conditions' => [
						'terms' => [
							[
								'name'  => 'custom_style',
								'value' => 'yes',
							],
						],
					],
				]
			);

			$repeater->add_control(
				'custom_button_second_box_shadow_color_hover',
				[
					'label' => __( 'Box Shadow Hover Color', 'TKV-addons' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .TKV-slides-elementor  {{CURRENT_ITEM}} .TKV-button-second:hover' => '--mt-color__primary--box-shadow: {{VALUE}}',
					],
					'conditions' => [
						'terms' => [
							[
								'name'  => 'custom_style',
								'value' => 'yes',
							],
						],
					],
				]
			);

			$repeater->add_control(
				'custom_button_second_hover_border_color',
				[
					'label' => __( 'Border Color', 'TKV-addons' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .TKV-slides-elementor  {{CURRENT_ITEM}} .TKV-button-second:hover' => 'border-color: {{VALUE}};',
					],
					'conditions' => [
						'terms' => [
							[
								'name'  => 'custom_style',
								'value' => 'yes',
							],
						],
					],
				]
			);

		$repeater->end_popover();

		$repeater->add_control(
			'after_button_heading_name',
			[
				'label' => esc_html__( 'After Button', 'TKV-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'after_button_mobile',
			[
				'label'       => esc_html__( 'Hide On Mobile', 'TKV-addons' ),
				'type'        => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Hide', 'TKV-addons' ),
				'label_off'    => __( 'Show', 'TKV-addons' ),
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				]
			]
		);

		$repeater->add_control(
			'after_button_custom_color',
			[
				'label'      => esc_html__( 'Color', 'TKV-addons' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor {{CURRENT_ITEM}} .TKV-slide__after-button' => 'color: {{VALUE}}',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'custom_navigation_heading',
			[
				'label'        => __( 'Navigation', 'TKV-addons' ),
				'type'         => Controls_Manager::POPOVER_TOGGLE,
				'label_off'    => __( 'Default', 'TKV-addons' ),
				'label_on'     => __( 'Custom', 'TKV-addons' ),
				'return_value' => 'yes',
				'separator' => 'before',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->start_popover();

		$repeater->add_control(
			'arrow_heading_name',
			[
				'label' => esc_html__( 'Arrow', 'TKV-addons' ),
				'type'  => Controls_Manager::HEADING,
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'sliders_arrow_color',
			[
				'label'     => esc_html__( 'Color', 'TKV-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'sliders_arrow_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'TKV-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'dot_heading_name',
			[
				'label' => esc_html__( 'Dots', 'TKV-addons' ),
				'type'  => Controls_Manager::HEADING,
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'sliders_dots_bgcolor',
			[
				'label'     => esc_html__( 'Background Color', 'TKV-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
				'frontend_available' => true,
			]
		);

		$repeater->add_control(
			'sliders_dots_active_bgcolor',
			[
				'label'     => esc_html__( 'Background Color Active', 'TKV-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'conditions' => [
					'terms' => [
						[
							'name'  => 'custom_style',
							'value' => 'yes',
						],
					],
				],
				'frontend_available' => true,
			]
		);

		$repeater->end_popover();

		$repeater->end_controls_tab();

		$repeater->end_controls_tabs();

		$this->add_control(
			'slides',
			[
				'label'      => esc_html__( 'Slides', 'TKV-addons' ),
				'type'       => Controls_Manager::REPEATER,
				'show_label' => true,
				'fields'     => $repeater->get_controls(),
				'default'    => [
					[
						'title'            => esc_html__( 'Slide 1 Title', 'TKV-addons' ),
						'description'      => esc_html__( 'Click edit button to change this text. Lorem ipsum dolor sit amet consectetur adipiscing elit dolor', 'TKV-addons' ),
						'button_text'      => esc_html__( 'Click Here', 'TKV-addons' ),
					],
					[
						'title'          => esc_html__( 'Slide 2 Title', 'TKV-addons' ),
						'description'      => esc_html__( 'Click edit button to change this text. Lorem ipsum dolor sit amet consectetur adipiscing elit dolor', 'TKV-addons' ),
						'button_text'      => esc_html__( 'Click Here', 'TKV-addons' ),
					],
					[
						'title'          => esc_html__( 'Slide 3 Title', 'TKV-addons' ),
						'description'      => esc_html__( 'Click edit button to change this text. Lorem ipsum dolor sit amet consectetur adipiscing elit dolor', 'TKV-addons' ),
						'button_text'      => esc_html__( 'Click Here', 'TKV-addons' ),
					],
				],
			]
		);

		$this->add_responsive_control(
			'slides_height',
			[
				'label'     => esc_html__( 'Height', 'TKV-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .item-slider' => 'height: {{SIZE}}{{UNIT}}',
				],
				'separator'  => 'before',
			]
		);

		$this->end_controls_section();
	}

	protected function section_content_option() {
		$this->start_controls_section(
			'section_slider_options',
			[
				'label' => esc_html__( 'Slider Options', 'TKV-addons' ),
				'type'  => Controls_Manager::SECTION,
			]
		);

		$this->add_responsive_control(
			'slides_to_show',
			[
				'label'              => esc_html__( 'Slides to show', 'TKV-addons' ),
				'type'               => Controls_Manager::NUMBER,
				'min'                => 1,
				'max'                => 10,
				'default'            => 1,
				'frontend_available' => true,
				'separator'          => 'before',
			]
		);

		$this->add_responsive_control(
			'slides_to_scroll',
			[
				'label'              => esc_html__( 'Slides to scroll', 'TKV-addons' ),
				'type'               => Controls_Manager::NUMBER,
				'min'                => 1,
				'max'                => 10,
				'default'            => 1,
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'effect',
			[
				'label'   => esc_html__( 'Effect', 'TKV-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'fade'   	 => esc_html__( 'Fade', 'TKV-addons' ),
					'slide' 	 => esc_html__( 'Slide', 'TKV-addons' ),
					'coverflow'	 => esc_html__( 'Coverflow', 'TKV-addons' ),
				],
				'default' => 'fade',
				'toggle'  => false,
				'frontend_available' => true,
			]
		);

		$this->add_responsive_control(
			'navigation',
			[
				'label'     => esc_html__( 'Navigation', 'TKV-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options' => [
					'none'   => esc_html__( 'None', 'TKV-addons' ),
					'arrows' => esc_html__( 'Arrows', 'TKV-addons' ),
					'dots' 	 => esc_html__( 'Dots', 'TKV-addons' ),
					'both'   => esc_html__( 'Arrows and Dots', 'TKV-addons' ),
				],
				'default' => 'arrows',
				'toggle'             => false,
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'   => esc_html__( 'Autoplay', 'TKV-addons' ),
				'type'    => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'TKV-addons' ),
				'label_off'    => __( 'No', 'TKV-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'delay',
			[
				'label'     => esc_html__( 'Delay', 'TKV-addons' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 3000,
				'description' => esc_html__('Delay between transitions (in ms). If this parameter is not specified, auto play will be disabled', 'TKV-addons'),
				'conditions' => [
					'terms' => [
						[
							'name'  => 'autoplay',
							'value' => 'yes',
						]
					],
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'autoplay_speed',
			[
				'label'     => esc_html__( 'Autoplay Speed', 'TKV-addons' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 1000,
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'infinite',
			[
				'label'   => esc_html__( 'Infinite Loop', 'TKV-addons' ),
				'type'    => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'TKV-addons' ),
				'label_off'    => __( 'No', 'TKV-addons' ),
				'return_value' => 'yes',
				'default'      => '',
				'frontend_available' => true,
			]
		);

		$this->end_controls_section();

	}

	// Tab Style
	protected function section_style() {
		$this->section_style_content();
		$this->section_style_carousel();
	}

	// Els
	protected function section_style_title() {

		$this->add_control(
			'heading_title',
			[
				'label'     => esc_html__( 'Title', 'TKV-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'      => esc_html__( 'Color', 'TKV-addons' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor .slick-slide-inner .TKV-slide__title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .TKV-slides-elementor .slick-slide-inner .TKV-slide__title',
			]
		);

		$this->add_responsive_control(
			'title_spacing',
			[
				'label'     => esc_html__( 'Spacing', 'TKV-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .slick-slide-inner .TKV-slide__title' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				],
			]
		);
	}

	protected function section_style_subtitle() {

		$this->add_control(
			'heading_subtitle',
			[
				'label'     => esc_html__( 'Subtitle', 'TKV-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'label'     => esc_html__( 'Color', 'TKV-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .TKV-slide__subtitle' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'subtitle_typography',
				'selector' => '{{WRAPPER}} .TKV-slides-elementor .TKV-slide__subtitle',
			]
		);

		$this->add_responsive_control(
			'subtitle_spacing',
			[
				'label'     => esc_html__( 'Spacing', 'TKV-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .slick-slide-inner .TKV-slide__subtitle' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				],
			]
		);

	}

	protected function section_style_before_desc() {

		$this->add_control(
			'heading_before_description',
			[
				'label'     => esc_html__( 'Before Description', 'TKV-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
			]
		);

		$this->add_control(
			'before_desc_color',
			[
				'label'      => esc_html__( 'Color', 'TKV-addons' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor .TKV-slide__before-description' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'before_desc_typography',
				'selector' => '{{WRAPPER}} .TKV-slides-elementor .TKV-slide__before-description',
			]
		);

		$this->add_responsive_control(
			'before_desc_spacing',
			[
				'label'     => esc_html__( 'Spacing', 'TKV-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .TKV-slide__before-description' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				],
			]
		);
	}

	protected function section_style_desc() {
		// Description
		$this->add_control(
			'heading_description',
			[
				'label'     => esc_html__( 'Description', 'TKV-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Color', 'TKV-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .TKV-slide__description' => 'color: {{VALUE}}',

				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .TKV-slides-elementor .TKV-slide__description',
			]
		);

		$this->add_responsive_control(
			'description_spacing',
			[
				'label'     => esc_html__( 'Spacing', 'TKV-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .slick-slide-inner .TKV-slide__description' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				],
			]
		);
	}

	protected function section_style_after_desc() {

		$this->add_control(
			'heading_after_description',
			[
				'label'     => esc_html__( 'After Description', 'TKV-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
			]
		);

		$this->add_control(
			'after_desc_color',
			[
				'label'      => esc_html__( 'Color', 'TKV-addons' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor .TKV-slide__after-description' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'after_desc_typography',
				'selector' => '{{WRAPPER}} .TKV-slides-elementor .TKV-slide__after-description',
			]
		);

		$this->add_responsive_control(
			'after_desc_spacing',
			[
				'label'     => esc_html__( 'Spacing', 'TKV-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .TKV-slide__after-description' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				],
			]
		);
	}

	protected function section_style_button() {

		$this->add_control(
			'heading_buton',
			[
				'label'     => esc_html__( 'Primary Button', 'TKV-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
			]
		);

		$this->add_control(
			'hide_button_mobile',
			[
				'label'        => esc_html__( 'Hide Button On Mobile', 'TKV-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_off'    => __( 'Off', 'TKV-addons' ),
				'label_on'     => __( 'On', 'TKV-addons' ),
				'return_value' => 'yes',
				'default'      => 'no'
			]
		);

		$controls = [
			'size'      => 'medium',
		];

		$this->register_button_style_controls($controls);

		$this->add_control(
			'button_2_heading',
			[
				'label' => esc_html__( 'Secondary Button', 'TKV-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$controls_second = [
			'prefix'   => 'second',
			'skin'     => 'subtle',
			'size'     => 'medium',
		];

		$this->register_button_style_controls( $controls_second );

		$this->add_responsive_control(
			'spacing_between_button',
			[
				'label'     => __( 'Spacing', 'TKV-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .TKV-button-second' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'heading_after_button',
			[
				'label'     => esc_html__( 'After Button', 'TKV-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
			]
		);

		$this->add_control(
			'after_button_color',
			[
				'label'      => esc_html__( 'Color', 'TKV-addons' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor .TKV-slide__after-button' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'after_button_typography',
				'selector' => '{{WRAPPER}} .TKV-slides-elementor .TKV-slide__after-button',
			]
		);

		$this->add_responsive_control(
			'after_button_spacing',
			[
				'label'     => esc_html__( 'Spacing', 'TKV-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .TKV-slide__after-button' => 'margin-top: {{SIZE}}{{UNIT}}',
				],
			]
		);
	}

	protected function section_style_image() {
		$this->add_control(
			'heading_image',
			[
				'label'     => esc_html__( 'Image', 'TKV-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator'  => 'before',
			]
		);


		$this->add_responsive_control(
			'image_custom_height',
			[
				'label'     => __( 'Height', 'TKV-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 1000,
						'min' => 0,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .TKV-slide__image' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_custom_position',
			[
				'label'                => esc_html__( 'Position Mobile', 'TKV-addons' ),
				'type'                 => Controls_Manager::CHOOSE,
				'label_block'          => false,
				'options'              => [
					'top'   => [
						'title' => esc_html__( 'Top Content', 'TKV-addons' ),
						'icon'  => 'eicon-v-align-top',
					],
					'bottom'  => [
						'title' => esc_html__( 'Bottom Content', 'TKV-addons' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'selectors'            => [
					'(mobile){{WRAPPER}} .TKV-slides-elementor .TKV-slide__image' => 'order: {{VALUE}}',
				],
				'selectors_dictionary' => [
					'top'   => '0',
					'bottom'  => '2',
				],
				'devices' => [ 'mobile'],
			]
		);
	}

	protected function section_style_content() {
		$this->start_controls_section(
			'section_style_slides',
			[
				'label' => esc_html__( 'Slides', 'TKV-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'space_between',
			[
				'label' => __( 'Gap', 'TKV-addons' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'default' => [],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'slides_container_width',
			[
				'label'      => esc_html__( 'Container Width', 'TKV-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 1900,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor .slick-slide-inner' => 'max-width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .TKV-slides-elementor .TKV-swiper-arrows-inner' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'slides_padding',
			[
				'label'      => esc_html__( 'Padding', 'TKV-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor .slick-slide-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'.TKV-rtl-smart {{WRAPPER}} .TKV-slides-elementor .slick-slide-inner' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'slides_radius',
			[
				'label'      => __( 'Border Radius', 'TKV-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor .item-slider' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .TKV-slides-elementor .TKV-slides-elementor__wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'slides_horizontal_position',
			[
				'label'                => esc_html__( 'Horizontal Position', 'TKV-addons' ),
				'type'                 => Controls_Manager::CHOOSE,
				'label_block'          => false,
				'options'              => [
					'left'   => [
						'title' => esc_html__( 'Left', 'TKV-addons' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'TKV-addons' ),
						'icon'  => 'eicon-h-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'TKV-addons' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'selectors'            => [
					'{{WRAPPER}} .TKV-slides-elementor .slick-slide-inner' => 'justify-content: {{VALUE}}',
				],
				'selectors_dictionary' => [
					'left'   => 'flex-start',
					'center' => 'center',
					'right'  => 'flex-end',
				],
			]
		);

		$this->add_responsive_control(
			'slides_vertical_position',
			[
				'label'                => esc_html__( 'Vertical Position', 'TKV-addons' ),
				'type'                 => Controls_Manager::CHOOSE,
				'label_block'          => false,
				'options'              => [
					'top'   => [
						'title' => esc_html__( 'Top', 'TKV-addons' ),
						'icon'  => 'eicon-v-align-top',
					],
					'middle' => [
						'title' => esc_html__( 'Middle', 'TKV-addons' ),
						'icon'  => 'eicon-v-align-middle',
					],
					'bottom'  => [
						'title' => esc_html__( 'Bottom', 'TKV-addons' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'selectors'            => [
					'{{WRAPPER}} .TKV-slides-elementor .slick-slide-inner' => 'align-items: {{VALUE}}',
				],
				'selectors_dictionary' => [
					'top'   => 'flex-start',
					'middle' => 'center',
					'bottom'  => 'flex-end',
				],
			]
		);

		$this->add_responsive_control(
			'slides_text_align',
			[
				'label'       => esc_html__( 'Text Align', 'TKV-addons' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options'     => [
					'left'   => [
						'title' => esc_html__( 'Left', 'TKV-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'TKV-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'TKV-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'     => 'left',
				'selectors'   => [
					'{{WRAPPER}} .TKV-slides-elementor .slick-slide-inner' => 'text-align: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'section_style_content',
			[
				'label' => esc_html__( 'Content', 'TKV-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'slides_content_width',
			[
				'label'      => esc_html__( 'Width', 'TKV-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 1900,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor .TKV-slide__content' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .TKV-slides-elementor .TKV-slide__image' => 'width: calc(100% - {{SIZE}}{{UNIT}} );',
					'(mobile){{WRAPPER}} .TKV-slides-elementor .TKV-slide__image' => 'width: 100%;',
				],
			]
		);

		$this->add_responsive_control(
			'slides_content_padding',
			[
				'label'      => esc_html__( 'Padding', 'TKV-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'placeholder' => [
					'top' => '38',
					'right' => '48',
					'bottom' => '48',
					'left' => '48',
				],
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor .TKV-slide__content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'.TKV-rtl-smart {{WRAPPER}} .TKV-slides-elementor .TKV-slide__content' => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
				],
			]
		);

		$this->section_style_subtitle();

		$this->section_style_title();

		$this->section_style_before_desc();

		$this->section_style_desc();

		$this->section_style_after_desc();

		$this->section_style_button();

		$this->section_style_image();

		$this->end_controls_section();

	}

	protected function section_style_carousel() {
		// Arrows
		$this->start_controls_section(
			'section_style_arrows',
			[
				'label' => esc_html__( 'Slider Options', 'TKV-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'centeredSlides',
			[
				'label'     => __( 'Center Mode on Mobile', 'TKV-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'TKV-addons' ),
				'label_on'  => __( 'On', 'TKV-addons' ),
				'default'   => '',
				'frontend_available' => true,
				'prefix_class' => 'TKV-slides__centeredslides-'
			]
		);

		// Arrows
		$this->add_control(
			'arrow_style_heading',
			[
				'label' => esc_html__( 'Arrows', 'TKV-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'arrows_icon',
			[
				'label'     => esc_html__( 'Icon Style', 'TKV-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'regular',
				'options'   => [
					'regular'   	=> esc_html__( 'Regular', 'TKV-addons' ),
					'thin' 	=> esc_html__( 'Thin', 'TKV-addons' ),
				],
			]
		);

		$this->add_control(
			'arrows_position',
			[
				'label'     => esc_html__( 'Position', 'TKV-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'center-center',
				'options'   => [
					'center-center'   	=> esc_html__( 'Center Center', 'TKV-addons' ),
					'right-bottom' 	=> esc_html__( 'Right Bottom', 'TKV-addons' ),
					'left-bottom' 	=> esc_html__( 'Left Bottom', 'TKV-addons' ),
				],
				'prefix_class' => 'TKV-slides__arrow-position-',
			]
		);

		$this->add_control(
			'sliders_arrow_style',
			[
				'label'        => __( 'Item Options', 'TKV-addons' ),
				'type'         => Controls_Manager::POPOVER_TOGGLE,
				'label_off'    => __( 'Default', 'TKV-addons' ),
				'label_on'     => __( 'Custom', 'TKV-addons' ),
				'return_value' => 'yes',
			]
		);

		$this->start_popover();

		$this->add_responsive_control(
			'sliders_arrows_size',
			[
				'label'     => __( 'Size', 'TKV-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .TKV-swiper-button' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sliders_arrows_width',
			[
				'label'     => __( 'Width', 'TKV-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'default' => [ 'size' => 44, 'unit' => 'px' ],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .TKV-swiper-button' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sliders_arrows_height',
			[
				'label'     => __( 'Height', 'TKV-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .TKV-swiper-button' => 'height: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'sliders_arrows_radius',
			[
				'label'      => __( 'Border Radius', 'TKV-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .TKV-slides-elementor .TKV-swiper-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'sliders_arrow_color',
			[
				'label'     => esc_html__( 'Color', 'TKV-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .TKV-swiper-button' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'sliders_arrow_bgcolor',
			[
				'label'     => esc_html__( 'Background Color', 'TKV-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .TKV-swiper-button' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'sliders_arrow_box_shadow',
				'label' => __( 'Box Shadow', 'TKV-addons' ),
				'selector' => '{{WRAPPER}} .TKV-swiper-button',
			]
		);

		$this->end_popover();

		$this->add_responsive_control(
			'sliders_arrows_horizontal_spacing',
			[
				'label'      => esc_html__( 'Horizontal Spacing', 'TKV-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => -100,
						'max' => 1170,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}}.TKV-slides__arrow-position-center-center .TKV-slides-elementor .TKV-swiper-button-prev' => 'left: {{SIZE}}{{UNIT}};',
					'.rtl {{WRAPPER}}.TKV-slides__arrow-position-center-center .TKV-slides-elementor .TKV-swiper-button-prev' => 'right: {{SIZE}}{{UNIT}}; left: auto;',
					'{{WRAPPER}}.TKV-slides__arrow-position-center-center .TKV-slides-elementor .TKV-swiper-button-next' => 'right: {{SIZE}}{{UNIT}};',
					'.rtl {{WRAPPER}}.TKV-slides__arrow-position-center-center .TKV-slides-elementor .TKV-swiper-button-next' => 'left: {{SIZE}}{{UNIT}}; right: auto;',
					'{{WRAPPER}}.TKV-slides__arrow-position-right-bottom .TKV-slides-elementor .TKV-swiper-button-prev' => 'right:  calc( 12px + {{sliders_arrows_width.SIZE}}{{sliders_arrows_width.UNIT}} + {{SIZE}}{{UNIT}} );',
					'.rtl {{WRAPPER}}.TKV-slides__arrow-position-right-bottom .TKV-slides-elementor .TKV-swiper-button-prev' => 'left:  calc( 12px + {{sliders_arrows_width.SIZE}}{{sliders_arrows_width.UNIT}} + {{SIZE}}{{UNIT}} ); right: auto;',
					'{{WRAPPER}}.TKV-slides__arrow-position-right-bottom .TKV-slides-elementor .TKV-swiper-button-next' => 'right: {{SIZE}}{{UNIT}};',
					'.rtl {{WRAPPER}}.TKV-slides__arrow-position-right-bottom .TKV-slides-elementor .TKV-swiper-button-next' => 'left: {{SIZE}}{{UNIT}}; right: auto;',
					'{{WRAPPER}}.TKV-slides__arrow-position-left-bottom .TKV-slides-elementor .TKV-swiper-button-prev' => 'left: {{SIZE}}{{UNIT}};',
					'.rtl {{WRAPPER}}.TKV-slides__arrow-position-left-bottom .TKV-slides-elementor .TKV-swiper-button-next' => 'right: {{SIZE}}{{UNIT}}; left: auto;',
					'{{WRAPPER}}.TKV-slides__arrow-position-left-bottom .TKV-slides-elementor .TKV-swiper-button-next' => 'left: calc( 12px + {{sliders_arrows_width.SIZE}}{{sliders_arrows_width.UNIT}} + {{SIZE}}{{UNIT}} );',
					'.rtl {{WRAPPER}}.TKV-slides__arrow-position-left-bottom .TKV-slides-elementor .TKV-swiper-button-prev' => 'right: calc( 12px + {{sliders_arrows_width.SIZE}}{{sliders_arrows_width.UNIT}} + {{SIZE}}{{UNIT}} ); left: auto;',
				],
			]
		);

		$this->add_responsive_control(
			'sliders_arrows_vertical_spacing',
			[
				'label'      => esc_html__( 'Vertical Spacing', 'TKV-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 1170,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}}.TKV-slides__arrow-position-center-center .TKV-swiper-button' => 'top: {{SIZE}}{{UNIT}} ;',
					'{{WRAPPER}}.TKV-slides__arrow-position-right-bottom .TKV-swiper-button' => 'bottom: {{SIZE}}{{UNIT}} ;',
					'{{WRAPPER}}.TKV-slides__arrow-position-left-bottom .TKV-swiper-button' => 'bottom: {{SIZE}}{{UNIT}} ;',
				],
			]
		);


		// Dots
		$this->add_control(
			'sliders_dots_style_heading',
			[
				'label' => esc_html__( 'Dots', 'TKV-addons' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'sliders_dots_position',
			[
				'label'     => esc_html__( 'Position', 'TKV-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'center',
				'options'   => [
					'center'   	=> esc_html__( 'Center', 'TKV-addons' ),
					'left' 	=> esc_html__( 'Left', 'TKV-addons' ),
					'right' 	=> esc_html__( 'Right', 'TKV-addons' ),
				],
				'prefix_class' => 'TKV-slides__dots-position-',
			]
		);

		$this->add_control(
			'sliders_dots_bg_overlay',
			[
				'label'     => __( 'Background Overlay', 'TKV-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'TKV-addons' ),
				'label_on'  => __( 'On', 'TKV-addons' ),
				'default'   => '',
			]
		);

		$this->add_control(
			'sliders_dots_bgcolor',
			[
				'label'     => esc_html__( 'Background Color', 'TKV-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination-bullets.swiper-pagination--background' => 'background-color : {{VALUE}};',
				],
				'condition' => [
					'sliders_dots_bg_overlay' => 'yes',
				],
			]
		);

		$this->add_control(
			'sliders_dots_style',
			[
				'label'        => __( 'Item Options', 'TKV-addons' ),
				'type'         => Controls_Manager::POPOVER_TOGGLE,
				'label_off'    => __( 'Default', 'TKV-addons' ),
				'label_on'     => __( 'Custom', 'TKV-addons' ),
				'return_value' => 'yes',
			]
		);

		$this->start_popover();

		$this->add_responsive_control(
			'sliders_dots_gap',
			[
				'label'     => __( 'Gap', 'TKV-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 50,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .swiper-pagination-bullet' => 'margin: 0 {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'sliders_dots_size',
			[
				'label'     => __( 'Size', 'TKV-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 100,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
			'sliders_dot_item_color',
			[
				'label'     => esc_html__( 'Color', 'TKV-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .swiper-pagination-bullet' => 'background-color : {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'sliders_dot_item_active_color',
			[
				'label'     => esc_html__( 'Color Active', 'TKV-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .swiper-pagination-bullet-active, {{WRAPPER}} .TKV-slides-elementor .swiper-pagination-bullet:hover' => 'background-color : {{VALUE}};',
				],
			]
		);

		$this->end_popover();

		$this->add_responsive_control(
			'sliders_dots_vertical_spacing',
			[
				'label'     => esc_html__( 'Vertical Spacing', 'TKV-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 1000,
						'min' => -200,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .TKV-slides-elementor .swiper-pagination' => 'bottom: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'sliders_dots_horizontal_spacing',
			[
				'label'      => esc_html__( 'Horizontal Spacing', 'TKV-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}}.TKV-slides__dots-position-center  .TKV-slides-elementor .swiper-pagination' => 'left: {{SIZE}}{{UNIT}};',
					'.rtl {{WRAPPER}}.TKV-slides__dots-position-center  .TKV-slides-elementor .swiper-pagination' => 'right: {{SIZE}}{{UNIT}}; left: auto;',
					'{{WRAPPER}}.TKV-slides__dots-position-right  .TKV-slides-elementor .swiper-pagination' => 'right: {{SIZE}}{{UNIT}};',
					'.rtl {{WRAPPER}}.TKV-slides__dots-position-right  .TKV-slides-elementor .swiper-pagination' => 'left: {{SIZE}}{{UNIT}}; right: auto;',
					'{{WRAPPER}}.TKV-slides__dots-position-left  .TKV-slides-elementor .swiper-pagination' => 'left: {{SIZE}}{{UNIT}};',
					'.rtl {{WRAPPER}}.TKV-slides__dots-position-left  .TKV-slides-elementor .swiper-pagination' => 'right: {{SIZE}}{{UNIT}}; left: auto;',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render icon box widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['slides'] ) ) {
			return;
		}

		$nav        = $settings['navigation'];
		$nav_tablet = empty( $settings['navigation_tablet'] ) ? $nav : $settings['navigation_tablet'];
		$nav_mobile = empty( $settings['navigation_mobile'] ) ? $nav : $settings['navigation_mobile'];

		$classes = [
			'TKV-slides-elementor',
			'TKV-swiper-carousel-elementor',
			'TKV-swiper-slider-elementor',
			'navigation-' . $nav,
			'navigation-tablet-' . $nav_tablet,
			'navigation-mobile-' . $nav_mobile,
		];

		$slide_count = 0;
		$button_slide_class = '';

		if( $settings['hide_button_mobile'] == 'yes' ){
			$button_slide_class .= 'hidden-xs';
		}

		$icon_left  = $settings['arrows_icon'] =='regular' ?  'left' : 'arrow-left-long';
		$icon_right = $settings['arrows_icon'] =='regular' ?  'right' : 'arrow-right-long';
		$dots_bg    = $settings['sliders_dots_bg_overlay'] == 'yes' ? 'swiper-pagination--background' : '';

		$this->add_render_attribute( 'wrapper', 'class', $classes );

		// Button
		$button_primary_class = 'TKV-button TKV-button-primary';

		if( $settings['primary_button_size'] !== 'normal' ) {
			$button_primary_class .= ' TKV-button--' . $settings['primary_button_size'] . ' ';
		}

		$button_primary_class .= ' TKV-button--' . $settings['primary_button_skin'] . ' ';

		if( $settings['primary_button_shape'] !== 'default' ) {
			$button_primary_class .= ' TKV-shape--' . $settings['primary_button_shape'] . ' ';
		}

		$button_second_class = 'TKV-button TKV-button-second';

		if( $settings['second_button_size'] !== 'normal' ) {
			$button_second_class .= ' TKV-button--' . $settings['second_button_size'] . ' ';
		}

		$button_second_class .= ' TKV-button--' . $settings['second_button_skin'] . ' ';

		if( $settings['second_button_shape'] !== 'default' ) {
			$button_second_class .= ' TKV-shape--' . $settings['second_button_shape'] . ' ';
		}

		?>
			<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
				<div class="TKV-slides-elementor__wrapper swiper-container">
					<div class="TKV-slides-elementor__inner swiper-wrapper">
						<?php
							foreach ( $settings['slides'] as $slide ) {
								$subtitle_image_mobile = ! empty( $slide['subtitle_image_mobile'] ) ? 'hidden-xs' : '';
								$data_arrow		  = $data_dots	= array();
								$slide_classes = ! empty( $slide['image']['url'] ) ? 'slide-has-image' : '';

								if( ! empty( $slide['sliders_arrow_color'] ) ) {
									$data_arrow['color'] = $slide['sliders_arrow_color'];
								}

								if( ! empty( $slide['sliders_arrow_background_color'] ) ) {
									$data_arrow['background_color'] = $slide['sliders_arrow_background_color'];
								}

								if( ! empty( $slide['sliders_dots_bgcolor'] ) ) {
									$data_dots['color'] = $slide['sliders_dots_bgcolor'];
								}

								if( ! empty( $slide['sliders_dots_active_bgcolor'] ) ) {
									$data_dots['color_active'] = $slide['sliders_dots_active_bgcolor'];
								}

								$key_primary_button = 'primary_button_' . $slide_count;
								$key_second_button = 'second_button_' . $slide_count;

								?>
									<div class="elementor-repeater-item-<?php echo esc_attr( $slide['_id'] ); ?> item-slider swiper-slide" data-dots="<?php echo htmlspecialchars( json_encode( $data_dots ) ); ?>" data-arrow="<?php echo htmlspecialchars( json_encode( $data_arrow ) ); ?>">
										<div class="slick-slide-inner <?php echo esc_attr( $slide_classes ); ?>">
											<div class="TKV-slide__content">
												<?php
													if( $slide['subtitle_type'] == 'text' ) {
														echo ! empty( $slide['subtitle'] ) ? '<div class="TKV-slide__subtitle ' . esc_attr( $subtitle_image_mobile ) . '">' . $slide['subtitle'] . '</div>' : '';
													} elseif ( $slide['subtitle_type'] == 'image' ) {
														echo ! empty( $slide['subtitle_image']['url'] ) ? '<div class="TKV-slide__subtitle TKV-slide__subtitle-image ' . esc_attr( $subtitle_image_mobile ) . '"><img alt="'. $slide['subtitle'] .'" src="' . esc_url( $slide['subtitle_image']['url'] ) .'"></div>' : '';
													} elseif ( $slide['subtitle_type'] == 'external' ) {
														echo ! empty( $slide['subtitle_external_url'] ) ? '<div class="TKV-slide__subtitle TKV-slide__subtitle-image ' . esc_attr( $subtitle_image_mobile ) . '"><img alt="'. $slide['subtitle'] .'" src="' . esc_url( $slide['subtitle_external_url'] ) .'"></div>' : '';
													} else {
														if( ! empty( $slide['subtitle_icon']['value'] ) ) {
															echo '<div class="TKV-slide__subtitle TKV-slide__subtitle-icon ' . esc_attr( $subtitle_image_mobile ) . '">';
																if ( 'svg' === $slide['subtitle_icon']['library'] ) {
																	echo Icons_Manager::render_uploaded_svg_icon( $slide['subtitle_icon']['value'] );
																} else {
																	echo Icons_Manager::render_font_icon( $slide['subtitle_icon'], [ 'aria-hidden' => 'true' ], 'i' );
																}
															echo '</div>';
														}
													}
												?>
												<?php if ( $slide['title'] ) : ?>
													<div class="TKV-slide__title"><?php echo $slide['title']; ?></div>
												<?php endif; ?>

												<?php if ( $slide['before_description'] ) : ?>
													<div class="TKV-slide__before-description"><?php echo $slide['before_description']; ?></div>
												<?php endif; ?>

												<?php if ( $slide['description'] ) : ?>
													<div class="TKV-slide__description"><?php echo $slide['description']; ?></div>
												<?php endif; ?>

												<?php if ( $slide['after_description'] ) : ?>
													<div class="TKV-slide__after-description"><?php echo $slide['after_description']; ?></div>
												<?php endif; ?>
												<div class="TKV-slide-button <?php echo esc_attr( $button_slide_class ); ?>">
													<?php echo $slide['primary_button_text'] ? Helper::control_url( $key_primary_button, $slide['primary_button_link'], '<span class="TKV-button__text">' . $slide['primary_button_text'] . '</span>', ['class' => esc_attr($button_primary_class)] ) : ''; ?>
													<?php echo $slide['second_button_text'] ? Helper::control_url( $key_second_button, $slide['second_button_link'], '<span class="TKV-button__text">' . $slide['second_button_text'] . '</span>', ['class' => esc_attr($button_second_class)] ) : ''; ?>
												</div>
												<?php if ( $slide['after_button'] ) : ?>
													<div class="TKV-slide__after-button <?php echo ! empty( $slide['after_button_mobile'] ) ? 'hidden-xs' : ''; ?>"><?php echo $slide['after_button']; ?></div>
												<?php endif; ?>

											</div>

											<?php echo ! empty( $slide['image']['url'] ) ? '<div class="TKV-slide__image"></div>' : ''; ?>
										</div>
										<?php echo ! empty( $slide['primary_button_link']['url'] ) && $slide['button_link_type'] == 'slide' ? Helper::control_url( 'btn_all', $slide['primary_button_link'], '', ['class' => 'button-link-all'] ) : ''; ?>
									</div>
								<?php

								$slide_count ++;
							}
						?>
					</div>
				</div>
				<div class="TKV-swiper-arrows-inner">
					<?php
						echo \TKV\Addons\Helper::get_svg( esc_attr( $icon_left ), 'ui' , [ 'class' => 'TKV-swiper-button-prev swiper-button TKV-swiper-button' ]  );
						echo \TKV\Addons\Helper::get_svg( esc_attr( $icon_right ), 'ui' , [ 'class' => 'TKV-swiper-button-next swiper-button TKV-swiper-button' ] );
					?>
				</div>
				<div class="swiper-pagination <?php echo esc_attr( $dots_bg ); ?>"></div>
			</div>
		<?php
	}
}